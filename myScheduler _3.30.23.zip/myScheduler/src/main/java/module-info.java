module jklimek.c195.myscheduler {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens jklimek.c195.myscheduler to javafx.fxml;
    exports jklimek.c195.myscheduler;
    exports jklimek.c195.myscheduler.Database;
    opens jklimek.c195.myscheduler.Database to javafx.fxml;
    exports jklimek.c195.myscheduler.models;
    opens jklimek.c195.myscheduler.models to javafx.fxml;
    exports jklimek.c195.myscheduler.controllers;
    opens jklimek.c195.myscheduler.controllers to javafx.fxml;
}