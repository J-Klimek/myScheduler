package jklimek.c195.myscheduler.controllers;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.DBCustomers;
import jklimek.c195.myscheduler.models.*;
import jklimek.c195.myscheduler.models.Alert;
import java.io.IOException;
import java.net.URL;
import java.nio.channels.spi.AbstractInterruptibleChannel;
import java.time.Month;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import static java.time.Month.*;

/**
 * Controller for the Report Form.
 * @author James Klimek | WGU CS195 Student
 */
public class reportFormController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TableView<Appointment> ApptTableView;
    @FXML
    private ComboBox<Month> apptMonthCombo;
    @FXML
    private Label apptMonthLabel;
    @FXML
    private Label signedInUserTxt;
    @FXML
    private ComboBox<String> apptTypeCombo;
    @FXML
    private Label apptTypeLabel;
    @FXML
    private Label mtCountLabel;
    @FXML
    private TableColumn<Appointment, Integer> csApptIDCol;
    @FXML
    private ComboBox<Contact> csContactCombo;
    @FXML
    private TableColumn<Appointment, Integer> csCustIDCol;
    @FXML
    private TableColumn<Appointment, String> csDescCol;
    @FXML
    private TableColumn<Appointment, String> csEndTimeCol;
    @FXML
    private TableColumn<Appointment, String> csStartTimeCol;
    @FXML
    private TableColumn<Appointment, String> csTitleCol;
    @FXML
    private TableColumn<Appointment, String> csTypeCol;
    @FXML
    private ComboBox<Country> tccCountryCombo;
    @FXML
    private Label tccCountryLabel;
    @FXML
    private Label tccCountLabel;


    /**
     * Method to set tableview to ALl appointments filtered by selected Contact.
     * Method streams a list of all appointments and filters to a new list based on the contactID of the selected contact.
     * Lambda used here for ease of iteration and filtering of the Collection.
     * @param event unused
     */
    @FXML
    public void OnActionFilterViewByContact(ActionEvent event) {
        List<Appointment> apptByContact = Appointment.allAppointments.stream()
                .filter(appt -> appt.getContactID() == csContactCombo.getValue().getContactID())
                .collect(Collectors.toList());
        ObservableList<Appointment> filteredByContact = FXCollections.observableArrayList(apptByContact);
        Contact selectedContact = csContactCombo.getSelectionModel().getSelectedItem();
        if(!apptByContact.isEmpty()) {
            ApptTableView.setItems(filteredByContact);
        }
        else{
            Alert.noApptsForContactAlert(selectedContact);
            ApptTableView.setItems(null);
        }
    }
    /**
     * Method to pop up a confirmation window when attempting to log out of the program.
     * Asks the user to confirm Logging out. Returns the user to the Log in screen.
     * @param event action event
     */
    @FXML
    public void OnActionLogout(ActionEvent event) {
        try {
            Alert.confirmLogoutAlert();
            Optional<ButtonType> result = Alert.confirmLogout.showAndWait();
            if(result.get() == ButtonType.OK) {
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/FXML/LoginForm.fxml"));
                stage.setScene(new Scene(scene));
                stage.setTitle(LoginFormController.getRb().getString("myScheduler") + " " + LoginFormController.getRb().getString("Login"));
                stage.show();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     * Method for opening the Appointments form.
     * @param event action event
     */
    @FXML
    public void OnActionOpenAppointments(ActionEvent event){
        try{
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/FXML/AppointmentsMainForm.fxml"));
        stage.setScene(new Scene(scene));
        stage.setTitle("Appointments");
        stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     * Method to open the customers form.
     * @param event action event
     */
    @FXML
    public void OnActionOpenCustomers(ActionEvent event){
        try {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/customersMain.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Customers");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method to set the appointment type label.
     * Sets the appointment type label with the user selection.
     * Creates an action event to trigger the onActionCountApptsMonthType() method.
     * @param event not used
     */
    @FXML
    void onActionSelectApptType(ActionEvent event) {
        apptTypeLabel.setText("Type: " + apptTypeCombo.getValue());
        ActionEvent ae = new ActionEvent();
        onActionCountApptsMonthType(ae);
    }
    /**
     * Method to count appointments by Month and Type.
     * Method streams a list of all appointments and filters to a new list
     * based on the selected Month for the current year and the selected Type of appointment.
     * Shows a count of the number of appointments for the selected Month and type.
     * Lambda used here for ease of iteration and filtering of the Collection.
     * @param event action event
     */
    @FXML
    public void onActionCountApptsMonthType(ActionEvent event) {
        List<Appointment> apptMonthTypeList = Appointment.allAppointments.stream()
                .filter(appt -> (appt.getApptStart().getMonth().equals(apptMonthCombo.getValue())) && (appt.getApptType().equalsIgnoreCase(apptTypeCombo.getValue())))
                .toList();
        long countOfMT = apptMonthTypeList.size();
        apptMonthLabel.setText("Month: " + apptMonthCombo.getValue());
        if(countOfMT == 1){
            mtCountLabel.setText(countOfMT + " appointment");
        }
        else{
            mtCountLabel.setText(countOfMT + " appointments");
        }
    }

    /**
     * Method to count Customers by Country.
     * Method streams a list of all Customers and filters to a new list based on the selected Country.
     * Shows a count of the customers from the selected Country by calling the customers.size() method.
     * Lambda used here for ease of iteration and filtering of the Collection.
     * @param event unused action event
     */
    @FXML
    public void onActionCountCountry(ActionEvent event) {
        List<Customer> customers = DBCustomers.getAllCustomers().stream().filter(c -> c.getCustomerCountry().equals(tccCountryCombo.getValue().getCountryName())).toList();
        int countryCustomerCount = customers.size();
        tccCountryLabel.setText(String.valueOf(tccCountryCombo.getValue().getCountryName()));
        if(countryCustomerCount == 1){
            tccCountLabel.setText(countryCustomerCount + " customer");
        }
        else{
            tccCountLabel.setText(countryCustomerCount + " customers");
        }
    }
    /**
     *Initializes the Report Form Controller.
     *Sets Tableview column names and populates contact schedule tableview.
     *Lambda expressions used in this method for setting the cell values for the tableview columns. The reason for the
     *use of lambda expressions is PropertyValueFactory is not typesafe.
     *
     * @param url
     * The location used to resolve relative paths for the root object, or
     * {@code null} if the location is not known.
     *
     * @param resourceBundle
     * The resources used to localize the root object, or {@code null} if
     * the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        User signedInUser = User.getSignedInUser();
        ApptTableView.setItems(Appointment.allAppointments);
        ObservableList<Month> months = FXCollections.observableArrayList(JANUARY,FEBRUARY,MARCH,APRIL,MAY,JUNE,JULY,AUGUST,SEPTEMBER,OCTOBER,NOVEMBER,DECEMBER);
        ObservableList<String> apptTypes = FXCollections.observableArrayList();
        for(Appointment a : Appointment.allAppointments){
            apptTypes.add(a.getApptType());
        }

        csApptIDCol.setCellValueFactory(apptID -> new SimpleIntegerProperty(apptID.getValue().getApptID()).asObject());
        csTitleCol.setCellValueFactory(title -> new SimpleStringProperty(title.getValue().getApptTitle()));
        csDescCol.setCellValueFactory(desc -> new SimpleStringProperty(desc.getValue().getApptDesc()));
        csTypeCol.setCellValueFactory(type -> new SimpleStringProperty(type.getValue().getApptType()));
        csStartTimeCol.setCellValueFactory(startTime -> new SimpleStringProperty(startTime.getValue().getApptStart().format(AppointmentsController.getFormatterDT()).toString() ));
        csEndTimeCol.setCellValueFactory(endTime -> new SimpleStringProperty(endTime.getValue().getApptEnd().format(AppointmentsController.getFormatterDT()).toString()));
        csCustIDCol.setCellValueFactory(custID -> new SimpleIntegerProperty(custID.getValue().getCustomerID()).asObject());
        csContactCombo.setItems(Contact.contactList);

        apptMonthCombo.setItems(months);
        apptTypeCombo.setItems(apptTypes);

        tccCountryCombo.setItems(Country.countryList);

        signedInUserTxt.setText("Currently Signed in as: " + signedInUser.getUserName());
    }
}
