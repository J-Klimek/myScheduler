package jklimek.c195.myscheduler.models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.Database.DBCountries;

/**
 * Country Class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class Country {
    private int countryID;
    private String countryName;
    public static ObservableList<Country> countryList = FXCollections.observableArrayList();

    /**
     * Default Constructor for Country Objects.
     * @param id Country ID
     * @param name Country Name
     */
    public Country(int id, String name){
        this.countryID = id;
        this.countryName = name;
    }

    /**
     * Method to Get the Country ID.
     * @return int Country ID
     */
    public int getCountryID(){
        return countryID;
    }

    /**
     * Method to Get the Country Name.
     * @return String Country Name
     */
    public String getCountryName(){
        return countryName;
    }
    /**
     * Static Method to Look up a Country by Name.
     * Searches the ObservableList of allCountries and creates a new ObservableList of one Country Object that
     * matches the Country name found in allCountries.
     * @param countryName Country Name
     * @return ObservableList of one Country object.
     */
    public static ObservableList<Country> lookupCountry(String countryName) {
        ObservableList<Country> namedCountries = FXCollections.observableArrayList();
        ObservableList<Country> allCountries = DBCountries.getAllCountries();
        for (Country c : allCountries) {
            if (c.getCountryName().contains(countryName)) {
                namedCountries.add(c);
            }
        }
        return namedCountries;
    }
    /**
     * Override Method of the toString() method.
     * Override toString() to allow proper formatting in combo boxes
     * @return String Country ID: Country Name
     */
    @Override
    public String toString(){
        return countryID + ": " + countryName;
    }

    /**
     * Override Method of the equals() method.
     * Override equals() to allow comparing new Objects created from DB query to existing ObservableList to avoid duplicates.
     * @param country Object country
     * @return false if null or not equal, else true.
     */
    @Override //
    public boolean equals(Object country) {
        if (country == null || getClass() != country.getClass()) {
            return false;
        }
        return this.countryID == ((Country) country).countryID;
    }

    /**
     * Override Method of the hashCode() method.
     * Override hashCode() to allow comparing new Objects created from DB query to existing ObservableList to avoid duplicates.
     * @return int Country ID
     */
    @Override //
    public int hashCode(){
        return countryID;
    }
}
