package jklimek.c195.myscheduler.models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.Database.DBDivisions;

/**
 * Division Class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class Division {
    private int divID;
    private String divName;
    private int countryID;
    public static ObservableList<Division> divisionsList = FXCollections.observableArrayList();

    /**
     * Default Constructor for Division Objects.
     */
    public Division(){}

    /**
     * Constructor for Division Objects.
     * @param divID Division ID
     * @param divName Division Name
     * @param countryID Country ID
     */
    public Division(int divID, String divName, int countryID) {
        this.divID = divID;
        this.divName = divName;
        this.countryID = countryID;
    }

    /**
     * Method to Get the Division ID.
     * @return int Division ID
     */
    public int getDivID() {
        return divID;
    }

    /**
     * Method to Get the Division Name.
     * @return String Division Name
     */
    public String getDivName() {
        return divName;
    }

    /**
     * Method to Get the Country ID.
     * @return int Country ID
     */
    public int getCountryID() {
        return countryID;
    }
    /**
     * Static Method to Look up a Division object by Name.
     * Takes in a Division name and searches the allDivisions list for the name and
     * creates a new ObservableList of one Division Object that matches the Name.
     * @param divName Division Name
     * @return ObservableList of one Division object
     */
    public static ObservableList<Division> lookupDivision(String divName) {
        ObservableList<Division> namedDivisions = FXCollections.observableArrayList();
        ObservableList<Division> allDivisions = DBDivisions.getAllDivisions();
        for (Division d : allDivisions) {
            if (d.getDivName().contains(divName)) {
                namedDivisions.add(d);
            }
        }
        return namedDivisions;
    }
    /**
     * Override Method of the toString() method.
     * Override toString() method to allow proper formatting in the combo boxes.
     * @return String Division ID: Division Name
     */
    @Override
    public String toString(){
        return divID + ": " + divName;
    }

    /**
     * Override Method of the equals() method.
     * Override equals() to allow comparing new Objects created from DB query
     * to existing ObservableList to avoid duplicates.
     * @param division Object division
     * @return false if null or not equal, else true.
     */
    @Override
    public boolean equals(Object division) {
        if (division == null || getClass() != division.getClass()) {
            return false;
        }
        return this.divID == ((Division) division).divID;
    }

    /**
     * Override Method of the hashCode() method.
     * Override hashCode() to allow comparing new Objects created from DB query
     * to existing ObservableList to avoid duplicates.
     * @return Division ID
     */
    @Override
    public int hashCode(){
        return divID;
    }
}
