package jklimek.c195.myscheduler.Database;


import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.models.User;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Database CRUD class for Appointments.
 * @author James Klimek | WGU CS195 Student
 */
public abstract class DBUsers {
    /**
     * Method to Get all users from the users table of the MySQL database.
     * @return ObservableList of User objects
     */
    public static ObservableList<User> getAllUsers() {
        String getAllUsersSql = "SELECT * FROM users";
        try {
            PreparedStatement ps = JDBConnection.getConnection().prepareStatement(getAllUsersSql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String userPW = rs.getString("Password");

                //create a new customer based on query result
                User newUser= new User(userID,userName,userPW);
                if (!User.allUsers.contains(newUser)) {
                    User.allUsers.add(newUser);  //add customer objects to allCustomers list
                }
            }
        } catch (
                SQLException e) {
            e.printStackTrace();
        }
        return User.allUsers;
    }

    /**
     * Method to verifyUser login.
     * This method checks the username and password entered against the database users to
     * verify the user for signing in to the program.
     * @param userName - Username from the login page username field
     * @param userPw - Password from the login page password field
     * @return - boolean true if username/password match the database or
     * false if username, password or both are not found or mismatched.
     */
    public static boolean verifyUser(String userName, String userPw) {
        String verifyUserSql = "SELECT * FROM users WHERE User_Name = ? AND Password = ?";
        try {
            PreparedStatement ps = JDBConnection.getConnection().prepareStatement(verifyUserSql);
            ps.setString(1, userName);
            ps.setString(2, userPw);
            ResultSet rs = ps.executeQuery();

            if (rs.isBeforeFirst()) {
                return true;
            }

        } catch (
                SQLException e) {
            e.printStackTrace();
        }
            return false;
    }

}
