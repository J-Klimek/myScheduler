package jklimek.c195.myscheduler.Database;

import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.models.Customer;
import java.sql.*;
import java.time.LocalDateTime;

/**
 * Database CRUD class for Customers.
 * @author James Klimek | WGU CS195 Student
 */
public abstract class DBCustomers {
    /**
     * Method to Get all customers from the customers table of the MySQL database.
     * @return ObservableList of Customer objects
     */
    public static ObservableList<Customer> getAllCustomers(){

        String getAllCustsql = "SELECT Customer_ID, Customer_Name, Address, Postal_Code, Phone, Country, Division, first_level_divisions.Division_ID " +
                                "FROM customers, countries, first_level_divisions " +
                                "WHERE customers.Division_ID = first_level_divisions.Division_ID " +
                                "AND first_level_divisions.Country_ID = countries.Country_ID";
        try {
            PreparedStatement ps = JDBConnection.getConnection().prepareStatement(getAllCustsql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String postalCode = rs.getString("Postal_Code");
                String customerPhone = rs.getString("Phone");
                String countryName = rs.getString("Country");
                String stateProv = rs.getString("Division");
                int divisionID = rs.getInt("Division_ID");

                //create a new customer based on query result
                Customer newCust = new Customer(customerID, customerName, customerAddress, postalCode, customerPhone, countryName, stateProv, divisionID);
                    if(!Customer.allCustomers.contains(newCust)) {
                        Customer.allCustomers.add(newCust);  //add customer objects to allCustomers list
                    }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Customer.allCustomers;
    }

    /**
     * Method to Insert a customer into the customers table in the MySQL database.
     * @param custName  Name of the Customer
     * @param custAddre  Address of the Customer
     * @param custPostCode  Postal Code of the Customer
     * @param custPhone  Phone number of the Customer
     * @param createDate  Date/time the Customer was created
     * @param createdBy  User that created the Customer
     * @param lastUpdated  Date/time the Customer was last updated
     * @param lastUpdateBy  User that last updated the Customer
     * @param divID  Division ID
     */
    public static void createCustomer(String custName, String custAddre, String custPostCode, String custPhone, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdated, String lastUpdateBy, int divID) {

        try{
        String createCustomerSql = "INSERT INTO customers VALUES(Null,?, ?, ?, ?, ?, ?, ?, ?, ?) ";
        PreparedStatement psCreateCust = JDBConnection.getConnection().prepareStatement(createCustomerSql, Statement.RETURN_GENERATED_KEYS);
        psCreateCust.setString(1, custName);
        psCreateCust.setString(2, custAddre);
        psCreateCust.setString(3, custPostCode);
        psCreateCust.setString(4, custPhone);
        psCreateCust.setTimestamp(5, Timestamp.valueOf(createDate));
        psCreateCust.setString(6, createdBy);
        psCreateCust.setTimestamp(7, Timestamp.valueOf(lastUpdated));
        psCreateCust.setString(8, lastUpdateBy);
        psCreateCust.setInt(9, divID);

        psCreateCust.executeUpdate();
        ResultSet rs = psCreateCust.getGeneratedKeys();
        rs.next();
        int customerID = rs.getInt(1);

        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

    /**
     * Method to update a customer in the customers table of the MySQL database.
     * @param custID  ID  of the Customer
     * @param custName  Name of the Customer
     * @param custAddre  Address of the Customer
     * @param custPostCode  Postal Code of the Customer
     * @param custPhone  Phone number of the Customer
     * @param lastUpdated  Date/time the customer was last updated
     * @param lastUpdateBy  User that last updated the customer
     * @param divID  Division ID
     */
    public static void updateCustomer(int custID, String custName, String custAddre,
                                      String custPostCode, String custPhone, LocalDateTime lastUpdated,
                                      String lastUpdateBy, int divID) {
        try {
            String updateCustomerSql = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Last_Update = ?, Last_Updated_By = ?, Division_ID = ? WHERE Customer_ID = ?";
            PreparedStatement psUpdateCust = JDBConnection.getConnection().prepareStatement(updateCustomerSql);
            psUpdateCust.setString(1, custName);
            psUpdateCust.setString(2, custAddre);
            psUpdateCust.setString(3, custPostCode);
            psUpdateCust.setString(4, custPhone);
            psUpdateCust.setTimestamp(5, Timestamp.valueOf(lastUpdated));
            psUpdateCust.setString(6, lastUpdateBy);
            psUpdateCust.setInt(7, divID);
            psUpdateCust.setInt(8, custID);

            psUpdateCust.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to delete a customer from the customers table of the MySQL database.
     * @param selectedCustomer  Customer to delete
     */
    public static void deleteCustomer(Customer selectedCustomer) {
        try {
            String deleteCustomerSql = "DELETE FROM customers WHERE Customer_ID = " + selectedCustomer.getCustomerID();
            PreparedStatement psDeleteCust = JDBConnection.getConnection().prepareStatement(deleteCustomerSql);
            psDeleteCust.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
