package jklimek.c195.myscheduler.models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.Database.DBContacts;

/**
 * Contact Class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class Contact {
    int contactID;
    String contactName;
    String contactEmail;
    public static ObservableList<Contact> contactList = FXCollections.observableArrayList();

    /**
     * Default Constructor for Contact Objects.
     */
    public Contact(){}

    /**
     * Constructor for Contact Objects with ID, Name and Email.
     * @param contactID Contact ID
     * @param contactName Contact Name
     * @param contactEmail Contact Email
     */
    public Contact(int contactID, String contactName, String contactEmail) {
        this.contactID = contactID;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    /**
     * Constructor for Contact Objects with ID and Name.
     * @param contactID Contact ID
     * @param contactName Contact Name
     */
    public Contact(int contactID, String contactName) {
        this.contactID = contactID;
        this.contactName = contactName;
    }

    /**
     * Method to Get the Contact ID.
     * @return int Contact ID
     */
    public int getContactID() {
        return contactID;
    }

    /**
     * Method to Get the Contact Name.
     * @return String Contact Name
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Method to Get the Contact Email.
     * @return String Contact Email
     */
    public String getContactEmail() {
        return contactEmail;
    }

    /**
     * Static Method to Look up a Contact by Contact ID.
     * Takes in a contact ID, searches a list of all contacts and
     * creates a new ObservableList of one Contact matching the Contact ID.
     * @param contactID Contact ID
     * @return ObservableList of one Contact Object
     */
    public static ObservableList<Contact> lookupContact(int contactID) {
        ObservableList<Contact> namedContacts = FXCollections.observableArrayList();
        ObservableList<Contact> allContacts = DBContacts.getAllContacts();
        for (Contact c : allContacts) {
            if (c.getContactID() == contactID) {
                namedContacts.add(c);
            }
        }
        return namedContacts;
    }

    /**
     * Override Method of the toString() method.
     * Override toString() to allow proper formatting in combo boxes.
     * @return String contact ID: contact Name
     */
    @Override //
    public String toString(){
        return contactID + ": " + contactName;
    }

    /**
     * Override Method of the equals() Method.
     * Override equals() to allow comparing new Objects created from DB query to existing ObservableList to avoid duplicates.
     * @param contact Contact Object
     * @return false if null or not equal, else true
     */
    @Override //
    public boolean equals(Object contact) {
        if (contact == null || getClass() != contact.getClass()) {
            return false;
        }
        return this.contactID == ((Contact) contact).contactID;
    }

    /**
     * Override Method of the hashCode() method.
     * Override hashCode() to allow comparing new Objects created from DB query to existing ObservableList to avoid duplicates
     * @return int Contact ID
     */
    @Override //
    public int hashCode(){
        return contactID;
    }
}
