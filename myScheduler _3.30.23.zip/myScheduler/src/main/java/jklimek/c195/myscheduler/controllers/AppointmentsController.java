package jklimek.c195.myscheduler.controllers;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.*;
import jklimek.c195.myscheduler.models.Alert;
import jklimek.c195.myscheduler.models.Appointment;
import jklimek.c195.myscheduler.models.Customer;
import jklimek.c195.myscheduler.models.User;
import java.net.URL;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Controller class for Appointments.
 * @author James Klimek | WGU CS195 Student
 */
public class AppointmentsController implements Initializable {

    Stage stage;
    Parent scene;
    private static final Locale LDT = Locale.getDefault();
    private static final WeekFields wf = WeekFields.of(LDT);
    private static Appointment selectedAppointment = null;
    private static final LocalDateTime currMonth = LocalDateTime.now(ZoneId.systemDefault());
    private static final DateTimeFormatter formatterDT = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm").localizedBy(LDT);
    private static final DateTimeFormatter formatterT = DateTimeFormatter.ofPattern("HH:mm").localizedBy(LDT);
    private static final ZoneId ESTZoneId = ZoneId.of("America/New_York");
    private static final ZonedDateTime officeOpenTime = ZonedDateTime.of(LocalDate.now(),LocalTime.of(8,0), ZoneId.of("America/New_York"));
    private static final ZonedDateTime officeCloseTime = ZonedDateTime.of(LocalDate.now(), LocalTime.of(22,0), ZoneId.of("America/New_York"));
    private static final ZoneId localZoneId = ZoneId.of(TimeZone.getDefault().getID());
    private static final ZonedDateTime localZDT = ZonedDateTime.of(LocalDateTime.now(),localZoneId);
    private static final ZonedDateTime officeOpenLocalzdt = officeOpenTime.withZoneSameInstant(localZoneId);
    private static final ZonedDateTime officeCloseLocalzdt = officeCloseTime.withZoneSameInstant(localZoneId);
    private static final LocalTime officeOpenLocal = LocalTime.from(officeOpenLocalzdt);
    private static final LocalTime officeCloseLocal = LocalTime.from(officeCloseLocalzdt);

    /**
     * Gets selected Appointment from the Appointment Tableview.
     * The selected appointment is used for the update and delete methods.
     * @return selectedAppointment
     */
    public static Appointment getSelectedAppointment(){
        return  selectedAppointment;
    }

    /**
     * Gets a DateTimeFormatter.
     * Format of HH:mm for use throughout the program to display time.
     * @return formatterT
     */
    public static DateTimeFormatter getFormatterT() {
        return formatterT;
    }
    /**
     * Gets a DateTimeFormatter.
     * Format of MM/dd/yyyy HH:mm for use throughout the program to display date and time.
     * @return formatterDT
     */
    public static DateTimeFormatter getFormatterDT() {
        return formatterDT;
    }

    /**
     * Gets the office open hour of 8AM in the users Local Time.
     * @return officeOpenLocal
     */
    public static LocalTime getOfficeOpenLocal() {
        return officeOpenLocal;
    }
    /**
     * Gets the office close hour of 10PM in the users Local Time.
     * @return officeCloseLocal
     */
    public static LocalTime getOfficeCloseLocal() {
        return officeCloseLocal;
    }


    @FXML
    private TableView<Appointment> ApptTableView;
    @FXML
    private ComboBox<Customer> apptCustomerCombo;
    @FXML
    private TableColumn<Appointment, Integer> apptIDCol;
    @FXML
    private TableColumn<Appointment, String> contactCol;
    @FXML
    private TableColumn<Appointment, Integer> custIDCol;
    @FXML
    private TableColumn<Appointment, String> descCol;
    @FXML
    private TableColumn<Appointment, String> locCol;
    @FXML
    private TableColumn<Appointment, String> startTimeCol;
    @FXML
    private TableColumn<Appointment, String> endTimeCol;
    @FXML
    private TableColumn<Appointment, String> titleCol;
    @FXML
    private TableColumn<Appointment, String> typeCol;
    @FXML
    private TableColumn<Appointment, Integer> userIDCol;
    @FXML
    private Label apptSignedInUserTxt;
    @FXML
    private RadioButton viewAllRadio;
    @FXML
    private RadioButton byMonthRadio;
    @FXML
    private RadioButton byWeekRadio;
    @FXML
    private ToggleGroup viewOptions;

    /**
     * Method to filter Appointments by Month.
     * @param event unused
     */
    @FXML
    public void OnActionSelectByMonth(ActionEvent event) {
        LocalDateTime currMonth = LocalDateTime.now(ZoneId.systemDefault());
        List<Appointment> sortByMonthList = Appointment.allAppointments.stream().filter(month -> month.getApptStart().getMonth() == currMonth.getMonth()).collect(Collectors.toList());
        ObservableList<Appointment> sortedByMonth = FXCollections.observableArrayList(sortByMonthList);
            if(!sortByMonthList.isEmpty()){
                ApptTableView.setItems(sortedByMonth);
                }
            else{
                Alert.noApptsMonthAlert();
                OnActionSelectViewAll(new ActionEvent());
            }
    }
    /**
     * Method to filter Appointments by Week.
     * Method streams a list of all appointments and filters to a new list based on the current week.
     * Lambda used here for ease of iteration and filtering of the Collection.
     * @param event unused
     */
    @FXML
    public void OnActionSelectByWeek(ActionEvent event) {
        List<Appointment> sortByWeekList = Appointment.allAppointments.stream()
                .filter(week -> week.getApptStart().get(wf.weekOfWeekBasedYear())
                        == currMonth.get(wf.weekOfWeekBasedYear()))
                .collect(Collectors.toList());
        ObservableList<Appointment> sortedByWeek = FXCollections.observableArrayList(sortByWeekList);
        if(!sortByWeekList.isEmpty()) {
            ApptTableView.setItems(sortedByWeek);
        }
        else{
            Alert.noApptsWeekAlert();
            OnActionSelectViewAll(new ActionEvent());
        }
    }
    /**
     * Method to set tableview to ALl appointments on mouseclick.
     * @param event unused
     */
    @FXML
    public void onMouseClickedViewAll(MouseEvent event) {
        ApptTableView.setItems(Appointment.allAppointments);
    }
    /**
     * Method to filter and set tableview to ALl appointments.
     * @param event unused
     */
    @FXML
    public void OnActionSelectViewAll(ActionEvent event) {
        ApptTableView.setItems(Appointment.allAppointments);
        viewAllRadio.setSelected(true);
    }
    /**
     * Method to set tableview to ALl appointments filtered by selected Customer.
     * Method streams a list of all appointments and filters to a new list based on the customerID of the selected customer.
     * Lambda used here for ease of iteration and filtering of the Collection.
     * @param event unused
     */
    @FXML
    public void OnActionFilterViewByCustomer(ActionEvent event) {
        List<Appointment> apptByCustomer = Appointment.allAppointments.stream()
                .filter(appt -> appt.getCustomerID() == apptCustomerCombo.getValue().getCustomerID())
                .collect(Collectors.toList());
        ObservableList<Appointment> filteredByCustomer = FXCollections.observableArrayList(apptByCustomer);
        Customer selectedCustomer = apptCustomerCombo.getSelectionModel().getSelectedItem();
        if(!apptByCustomer.isEmpty()) {
            ApptTableView.setItems(filteredByCustomer);
        }
        else{
            Alert.noApptsForCustomerAlert(selectedCustomer);
            ApptTableView.setItems(null);
        }
    }
    /**
     *  Method for deleting the appointment selected in the appointment tableview.
     * @param event action event
     */
    @FXML
    public void OnActionDeleteAppt(ActionEvent event) {
        boolean delAppt = false;
        Appointment apptToDelete = ApptTableView.getSelectionModel().getSelectedItem();
        try {
            delAppt = Appointment.deleteAppointment(apptToDelete);
            if (delAppt) {
                Alert.confirmDeleteAppointmentAlert(apptToDelete);
                Optional<ButtonType> result = Alert.confirmDelete.showAndWait();
                if (result.get() == ButtonType.OK) {
                    Appointment.allAppointments.remove(apptToDelete);
                    DBAppointments.deleteAppointment(apptToDelete);
                }
            }
        }catch(Exception e){
            Alert.invalidSelectionAlert();
        }
    }
    /**
     * Method to pop up a confirmation window when attempting to log out of the program.
     * Asks the user to confirm Logging out. Returns the user to the Log in screen.
     * @param event action event
     */
    @FXML
    public void OnActionLogout(ActionEvent event){
        try {
            Alert.confirmLogoutAlert();
            Optional<ButtonType> result = Alert.confirmLogout.showAndWait();
                if(result.get() == ButtonType.OK) {
                    stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                    scene = FXMLLoader.load(getClass().getResource("/FXML/LoginForm.fxml"));
                    stage.setScene(new Scene(scene));
                    stage.setTitle(LoginFormController.getRb().getString("myScheduler") + " " + LoginFormController.getRb().getString("Login"));
                    stage.show();
                }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     *  Method for opening the create new appointment form.
     * @param event action event
     */
    @FXML
    public void OnActionNewAppt(ActionEvent event){
        try {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/newApptForm.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("New Appointment");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     * Method to open the customers form.
     */
    @FXML
    void OnActionOpenCustomers(ActionEvent event){
        try{
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/FXML/customersMain.fxml"));
        stage.setScene(new Scene(scene));
        stage.setTitle("Customers");
        stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     * Method to open the Reports form.
     */
    @FXML
    void OnActionOpenReports(ActionEvent event){
        try{
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/FXML/reportForm.fxml"));
        stage.setScene(new Scene(scene));
        stage.setTitle("Reports");
        stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     * Method to open the update appointment form.
     * Passes in the selectedAppointment object to the update appointment form.
     */
    @FXML
    void OnActionUpdateAppt(ActionEvent event){
        selectedAppointment = ApptTableView.getSelectionModel().getSelectedItem();
        try {
            if (ApptTableView.getSelectionModel().isEmpty()) {
                Alert.invalidSelectionAlert();
                return;
            }
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/FXML/updateApptForm.fxml"));
        stage.setScene(new Scene(scene));
        stage.setTitle("Update Appointment");
        stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     *Initializes the Appointment Controller.
     *Sets Tableview column names and populates appointment tableview.
     *Populates the Appointment TableView with All added Appointment Objects pulled from the MySQL database.
     *Lambda expressions used in this method for setting the cell values for the tableview columns. The reason for the
     *use of lambda expressions is PropertyValueFactory is not typesafe.
     *
     * @param url
     * The location used to resolve relative paths for the root object, or
     * {@code null} if the location is not known.
     *
     * @param resourceBundle
     * The resources used to localize the root object, or {@code null} if
     * the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        DBAppointments.getAllAppointments();
        DBCustomers.getAllCustomers();
        DBContacts.getAllContacts();
        DBCountries.getAllCountries();
        DBDivisions.getAllDivisions();
        User signedInUser = User.getSignedInUser();
        ApptTableView.setItems(Appointment.allAppointments);


        apptIDCol.setCellValueFactory(apptID -> new SimpleIntegerProperty(apptID.getValue().getApptID()).asObject());
        titleCol.setCellValueFactory(title -> new SimpleStringProperty(title.getValue().getApptTitle()));
        descCol.setCellValueFactory(desc -> new SimpleStringProperty(desc.getValue().getApptDesc()));
        locCol.setCellValueFactory(loc -> new SimpleStringProperty(loc.getValue().getApptLoc()));
        contactCol.setCellValueFactory(contact -> new SimpleStringProperty(contact.getValue().getContactName()));
        typeCol.setCellValueFactory(type -> new SimpleStringProperty(type.getValue().getApptType()));
        startTimeCol.setCellValueFactory(startTime -> new SimpleStringProperty(startTime.getValue().getApptStart().format(formatterDT).toString() ));
        endTimeCol.setCellValueFactory(endTime -> new SimpleStringProperty(endTime.getValue().getApptEnd().format(formatterDT).toString()));
        custIDCol.setCellValueFactory(custID -> new SimpleIntegerProperty(custID.getValue().getCustomerID()).asObject());
        userIDCol.setCellValueFactory(userID -> new SimpleIntegerProperty(userID.getValue().getUserID()).asObject());
        apptCustomerCombo.setItems(Customer.allCustomers);
        apptSignedInUserTxt.setText("Currently Signed in as: " + signedInUser.getUserName());

    }
}
