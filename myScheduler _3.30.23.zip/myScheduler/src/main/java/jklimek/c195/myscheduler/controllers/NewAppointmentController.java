package jklimek.c195.myscheduler.controllers;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.DBAppointments;
import jklimek.c195.myscheduler.models.*;
import jklimek.c195.myscheduler.models.Alert;
import java.net.URL;
import java.time.*;
import java.util.ResourceBundle;
import static java.time.LocalDateTime.now;

/**
 * Controller class for New Appointment Form.
 * @author James Klimek | WGU CS195 Student
 */
public class NewAppointmentController implements Initializable {
    Stage stage;
    Parent scene;


    @FXML
    private ComboBox<Contact> newApptContactCombo;
    @FXML
    private TextArea newApptDescTxt;
    @FXML
    private TextField newApptIdTxt;
    @FXML
    private TextField newApptLocTxt;
    @FXML
    private DatePicker newApptStartDate;
    @FXML
    private ComboBox newApptStartTime;
    @FXML
    private DatePicker newApptEndDate;
    @FXML
    private ComboBox newApptEndTime;
    @FXML
    private TextField newApptTitleTxt;
    @FXML
    private TextField newApptTypeTxt;
    @FXML
    private ComboBox<Customer> newApptCustIDCombo;
    @FXML
    private ComboBox<User> newApptUserIDCombo;

    /**
     * Method to cancel new appointment creation.
     * @param event action event
     */
    @FXML
    public void OnActionNewApptCancel(ActionEvent event){
        try {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/AppointmentsMainForm.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Appointments");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method to Add/Insert a New Appointment.
     * Method takes the input from the user in the form fields and sets them to the
     * respective attributes of a New Appointment object.
     * The information is run through input validation to ensure nothing is blank and the date/times do not overlap
     * with exisiting appointments.
     * The new appointment object is then inserted into the MySQL database calling the DBAppointments createAppointment
     * method.
     * @param event action event
     */
    @FXML
    public void OnActionNewApptSave(ActionEvent event) {
        User signedInUser = User.getSignedInUser();
        String apptTitle;
        String apptDesc;
        String apptLoc;
        String apptType;
        LocalDate apptStartDate;
        LocalTime apptStartTime;
        LocalDateTime apptStartLDT;
        LocalDate apptEndDate;
        LocalTime apptEndTime;
        LocalDateTime apptEndLDT;
        LocalTime officeOpen = LocalTime.parse(AppointmentsController.getOfficeOpenLocal().format(AppointmentsController.getFormatterT()));
        LocalTime officeClose = LocalTime.parse(AppointmentsController.getOfficeCloseLocal().format(AppointmentsController.getFormatterT()));
        LocalDateTime createDate = now();
        String createdBy = signedInUser.getUserName();
        LocalDateTime apptLastUpdated = now();
        String apptLastUpdatedBy = signedInUser.getUserName();
        int customerID;
        int userID;
        int contactID;

        try{
            apptTitle = newApptTitleTxt.getText();
            if(apptTitle.isBlank()){
                Alert.invalidTitleAlert();
                return;
            }
            apptDesc = newApptDescTxt.getText();
            if(apptDesc.isBlank()){
                Alert.invalidDescriptionAlert();
                return;
            }
            apptLoc = newApptLocTxt.getText();
            if(apptLoc.isBlank()){
                Alert.invalidLocationAlert();
                return;
            }
            apptType = newApptTypeTxt.getText();
            if(apptType.isBlank()){
                Alert.invalidTypeAlert();
                return;
            }
            if(newApptCustIDCombo.getSelectionModel().isEmpty()){
                Alert.invalidCustomerIDAlert();
                return;
            }
            if(newApptUserIDCombo.getSelectionModel().isEmpty()){
                Alert.invalidUserIDAlert();
                return;
            }
            if(newApptContactCombo.getSelectionModel().isEmpty()){
                Alert.invalidContactIDAlert();
                return;
            }
            customerID = newApptCustIDCombo.getValue().getCustomerID();
            userID = newApptUserIDCombo.getValue().getUserID();
            contactID = newApptContactCombo.getValue().getContactID();
            if(newApptStartTime.getSelectionModel().isEmpty()) {
                Alert.invalidNullDateTimeAlert();
                return;
            }
            if(newApptEndTime.getSelectionModel().isEmpty()) {
                Alert.invalidNullDateTimeAlert();
                return;
            }
            apptStartDate = newApptStartDate.getValue();
            apptStartTime = LocalTime.parse(newApptStartTime.getValue().toString());

            apptEndDate = newApptEndDate.getValue();
            apptEndTime = LocalTime.parse(newApptEndTime.getValue().toString());

            apptStartLDT = LocalDateTime.of(apptStartDate, apptStartTime);
            apptEndLDT = LocalDateTime.of(apptEndDate, apptEndTime);
            // check for overlapping appointments
            for(Appointment appt : Appointment.allAppointments) {
                if (customerID == appt.getCustomerID()) {
                    if ((apptStartLDT.isAfter(appt.getApptStart()) || apptStartLDT.isEqual(appt.getApptStart()))
                            && apptStartLDT.isBefore(appt.getApptEnd())) {
                        Alert.overlappingAppointmentAlert();
                        return;
                    } else if ((apptEndLDT.isBefore(appt.getApptEnd()) || apptEndLDT.isEqual(appt.getApptEnd()))
                            && apptEndLDT.isAfter(appt.getApptStart())) {
                        Alert.overlappingAppointmentAlert();
                        return;
                    } else if ((apptStartLDT.isBefore(appt.getApptStart()) || apptStartLDT.isEqual(appt.getApptStart()))
                            && ((apptEndLDT.isAfter(appt.getApptEnd()) || apptEndLDT.isEqual(appt.getApptEnd())))) {
                        Alert.overlappingAppointmentAlert();
                        return;
                    }
                }
            }

            if(apptStartTime.isBefore(officeOpen) || apptEndTime.isAfter(officeClose)) {
                Alert.outsideBusinessHoursAlert(apptStartTime, apptEndTime);
                return;
            }
            if(apptEndTime.isBefore(apptStartTime)){
                Alert.invalidTimeSelectionAlert();
                return;
            }


        DBAppointments.createAppointment(apptTitle,apptDesc,apptLoc,apptType,apptStartLDT,apptEndLDT,
                createDate,createdBy,apptLastUpdated,apptLastUpdatedBy,
                customerID,userID,contactID);

            DBAppointments.getAllAppointments();

            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/AppointmentsMainForm.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Appointments");
            stage.show();
        }catch(Exception e){
        e.printStackTrace();
        }
    }
/**
 * Initializes the NewAppointment Controller.
 * Populates the Customer ID, Contact, and UserID comboboxes with values from the Customer.allCustomers,
 * Contact.contactList, and User.allUsers ObservableLists respectively.
 */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Contact> contacts = Contact.contactList;
        ObservableList<Customer> customers = Customer.allCustomers;
        ObservableList<User> users = User.allUsers;
        LocalTime startAppt = LocalTime.of(1,0);
        LocalTime endAppt = LocalTime.of(23, 0);

        newApptCustIDCombo.setItems(customers);
        newApptContactCombo.setItems(contacts);
        newApptUserIDCombo.setItems(users);
        while(startAppt.isBefore(endAppt)) {
            newApptStartTime.getItems().add(startAppt.format(AppointmentsController.getFormatterT()));
            newApptEndTime.getItems().add(startAppt.plusMinutes(30).format(AppointmentsController.getFormatterT()));
            startAppt = startAppt.plusHours(1);
        }
    }
}
