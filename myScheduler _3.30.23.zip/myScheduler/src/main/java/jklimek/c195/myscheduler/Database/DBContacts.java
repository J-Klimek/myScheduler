package jklimek.c195.myscheduler.Database;

import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.models.Contact;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Database Access class for Contacts.
 * @author James Klimek | WGU CS195 Student
 */
public abstract class DBContacts {
    /**
     * Method to Get all contacts from the contacts table of the MySQL database.
     * @return ObservableList of Contact objects
     */
    public static ObservableList<Contact> getAllContacts() {
        String getAllContactsSql = "SELECT * FROM contacts";

        try {
            PreparedStatement ps = JDBConnection.getConnection().prepareStatement(getAllContactsSql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String contactEmail = rs.getString("Email");

                //create a new customer based on query result
                Contact newContact = new Contact(contactID,contactName,contactEmail);
                if (!Contact.contactList.contains(newContact)) {
                    Contact.contactList.add(newContact);  //add customer objects to allCustomers list
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Contact.contactList;
    }
}
