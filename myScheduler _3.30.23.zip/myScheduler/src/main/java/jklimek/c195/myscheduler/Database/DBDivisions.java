package jklimek.c195.myscheduler.Database;


import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.models.Division;
import java.sql.*;

/**
 * Database Access class for Divisions.
 * @author James Klimek | WGU CS195 Student
 */
public abstract class DBDivisions {
    /**
     * Method to Get all Divisions from the first_level_divisions table of the MySQL database.
     * @return ObservableList of Division objects
     */
    public static ObservableList<Division> getAllDivisions(){

        try{
            String getAllDivsSql = "SELECT * from first_level_divisions";
            PreparedStatement ps = JDBConnection.getConnection().prepareStatement(getAllDivsSql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt(("Country_ID"));
                Division division = new Division(divisionID, divisionName, countryID);

                if(!Division.divisionsList.contains(division)){
                    Division.divisionsList.add(division);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return Division.divisionsList;
    }
}
