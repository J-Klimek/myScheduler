package jklimek.c195.myscheduler.controllers;

import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Parent;
import jklimek.c195.myscheduler.Database.DBCustomers;
import jklimek.c195.myscheduler.Database.DBDivisions;
import jklimek.c195.myscheduler.models.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import java.util.function.Predicate;

import static java.time.LocalDateTime.now;

/**
 * Controller class for Update Customer Form.
 * @author James Klimek | WGU CS195 Student
 */
public class UpdateCustomerController implements Initializable {
    Stage stage;
    Parent scene;
    private Customer customerToUpdate = CustomerController.getSelectedCustomer();

    @FXML
    private TextField updateCustomerIdTxt;
    @FXML
    private TextField updateAddressTxt;
    @FXML
    private ComboBox<Country> updateCountryCombo;
    @FXML
    private TextField updateNameTxt;
    @FXML
    private TextField updatePhoneTxt;
    @FXML
    private TextField updatePostalTxt;
    @FXML
    private ComboBox<Division> updateDivisionCombobox;

    /**
     * Method for the Country Combo Box.
     * Selected Country will update the Division combo box based on selection.
     * Lambda used here for ease of iteration and filtering of the Collection.
     * @param event action event
     */
    @FXML
    void onActionCountryCBSelect(ActionEvent event) {
        Country selectedCountry = updateCountryCombo.getValue();
        Predicate<Division> countrySel = selCountry -> selCountry.getCountryID() == updateCountryCombo.getSelectionModel().getSelectedItem().getCountryID();
        ObservableList<Division> allDivisions = DBDivisions.getAllDivisions();
        FilteredList<Division> countryDivision = new FilteredList<>(allDivisions, countrySel);

        if(selectedCountry == null){
            countryDivision.setPredicate(null);
        }
        else{
            countryDivision.setPredicate(countrySel);
            updateDivisionCombobox.setItems(countryDivision);
        }
    }

    /**
     * Method to cancel updating a Customer.
     * @param event action event
     */
    @FXML
    void OnActionCustUpdateCancel(ActionEvent event){
        try {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/customersMain.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Customers");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method to Update the Customer.
     * Updates the selected customer object attributes with the values from
     * the fields in the update form. Uses input validation to disallow blank entries.
     * Calls the DBCustomers update method to update
     * the customer in the customers table of the MySQL database. Updates the Customer object in
     * Customers class Observable list allCustomers.
     * @param event action event
     */
    @FXML
    void OnActionCustUpdateSave(ActionEvent event){

        User signedInUser = User.getSignedInUser();
        String customerName;
        String customerAddress;
        String customerPostal;
        String customerPhone;
        String customerCountry;
        String customerDivision;
        LocalDateTime updatedDate = now();
        String updatedBy = signedInUser.getUserName();
        int customerID;

        try {
            customerName = updateNameTxt.getText();
            customerAddress = updateAddressTxt.getText();
            customerPostal = updatePostalTxt.getText();
            customerPhone = updatePhoneTxt.getText();
            customerID = Integer.parseInt(updateCustomerIdTxt.getText());

            if (customerName.isBlank()) {
                Alert.error = "Name";
                Alert.blankEntryAlert();
                return;
            }
            if (customerAddress.isBlank()) {
                Alert.error = "Address";
                Alert.blankEntryAlert();
                return;
            }
            if (customerPostal.isBlank()) {
                Alert.error = "Postal Code";
                Alert.blankEntryAlert();
                return;
            }
            if (customerPhone.isBlank()) {
                Alert.error = "Phone";
                Alert.blankEntryAlert();
                return;
            }
            if (updateCountryCombo.getSelectionModel().isEmpty()) {
                Alert.error = "Country";
                Alert.blankEntryAlert();
                return;
            }
            if (updateDivisionCombobox.getSelectionModel().isEmpty()) {
                Alert.error = "Division";
                Alert.blankEntryAlert();
                return;
            }
            int customerDivId = Division.lookupDivision(updateDivisionCombobox.getValue().getDivName()).get(0).getDivID();
            customerCountry = updateCountryCombo.getValue().getCountryName().toString();
            customerDivision = updateDivisionCombobox.getValue().getDivName();

            DBCustomers.updateCustomer(customerID, customerName, customerAddress,
                    customerPostal, customerPhone, updatedDate,
                    updatedBy, customerDivId);

            Customer updatedCustomer = new Customer(customerID, customerName, customerAddress, customerPostal,
                    customerPhone, customerCountry, customerDivision, customerDivId);
            Customer.updateCustomer(Customer.getAllCustomers().indexOf(customerToUpdate), updatedCustomer);


            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/customersMain.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Customers");
            stage.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method that initializes the Update Customer form.
     * Sets the form fields with the values from the selected customer of the Customers tableview.
     * Populates the Country and Division combo boxes with values from the Country class ObservableList allCountries
     * and the Division class ObservableList allDivisions respectively.
     * Lambda expressions used in this method for setting the cell values for the tableview columns.
     * The reason for the
     * use of lambda expressions is PropertyValueFactory is not typesafe.
     * @param url
     * The location used to resolve relative paths for the root object, or
     * {@code null} if the location is not known.
     *
     * @param resourceBundle
     * The resources used to localize the root object, or {@code null} if
     * the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Customer selectedCustomer = CustomerController.getSelectedCustomer();

        String custID = String.valueOf(selectedCustomer.getCustomerID());
        String custName = selectedCustomer.getCustomerName();
        String custAddress = selectedCustomer.getCustomerAddress();
        String custPostal = selectedCustomer.getCustomerPostalCode();
        String custPhone = selectedCustomer.getCustomerPhoneNum();
        Country currCountry = new Country(Country.lookupCountry(selectedCustomer.getCustomerCountry()).get(0).getCountryID(), selectedCustomer.getCustomerCountry());
        Division currDivision = new Division(Division.lookupDivision(selectedCustomer.getCustomerDivision()).get(0).getDivID(), selectedCustomer.getCustomerDivision(), Country.lookupCountry(selectedCustomer.getCustomerCountry()).get(0).getCountryID());
        ObservableList<Country> countries = Country.countryList;
        ObservableList<Division> allDivisions = Division.divisionsList;

        updateCustomerIdTxt.setText(custID);
        updateNameTxt.setText(custName);
        updateAddressTxt.setText(custAddress);
        updatePostalTxt.setText(custPostal);
        updatePhoneTxt.setText(custPhone);
        updateCountryCombo.setItems(countries);
        updateCountryCombo.setValue(currCountry);
        updateDivisionCombobox.setValue(currDivision);
        Predicate<Division> countrySel = selCountry -> selCountry.getCountryID() == updateCountryCombo.getSelectionModel().getSelectedItem().getCountryID();
        FilteredList<Division> countryDivision = new FilteredList<>(allDivisions, countrySel);
        Country selectedCountry = updateCountryCombo.getValue();

        if(selectedCountry == null){
            countryDivision.setPredicate(null);
        }
        else{
            countryDivision.setPredicate(countrySel);
            updateDivisionCombobox.setItems(countryDivision);
        }
    }
}
