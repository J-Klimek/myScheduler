package jklimek.c195.myscheduler.controllers;

import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.DBCustomers;
import jklimek.c195.myscheduler.Database.DBCountries;
import jklimek.c195.myscheduler.Database.DBDivisions;
import jklimek.c195.myscheduler.models.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import java.util.function.Predicate;
import static java.time.LocalDateTime.now;

/**
 * Controller class for New Customers.
 * @author James Klimek | WGU CS195 Student
 */
public class NewCustomerController implements Initializable {
    Stage stage;
    Parent scene;


    @FXML
    private ComboBox<Country> countryCombo;

    @FXML
    private TextField customerIdTxt;

    @FXML
    private TextField newAddressTxt;

    @FXML
    private TextField newNameTxt;

    @FXML
    private TextField newPhoneTxt;

    @FXML
    private TextField newPostalTxt;

    @FXML
    private ComboBox<Division> divisionCombobox;

    /**
     * Method to cancel creating a new customer.
     * @param event not used
     */
    @FXML
    public void OnActionNewCustCancel(ActionEvent event){
        try {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/customersMain.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Customers");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method to create a new Customer.
     * Creates a new customer object from the information provided
     * by the user in the fields of the new customer form. Implements input validation to disallow blank entries.
     * @param event not used
     */
    @FXML
    public void OnActionNewCustSave(ActionEvent event){

        User signedInUser = User.getSignedInUser();
        String customerName;
        String customerAddress;
        String customerPostal;
        String customerPhone;
        LocalDateTime createDate = now();
        String createdBy = signedInUser.getUserName();
        LocalDateTime updatedDate = now();
        String updatedBy = signedInUser.getUserName();

        try {
            customerName = newNameTxt.getText();
            customerAddress = newAddressTxt.getText();
            customerPostal = newPostalTxt.getText();
            customerPhone = newPhoneTxt.getText();

            if (customerName.isBlank()) {
                Alert.error = "Name";
                Alert.blankEntryAlert();
                return;
            }
            if (customerAddress.isBlank()) {
                Alert.error = "Address";
                Alert.blankEntryAlert();
                return;
            }
            if (customerPostal.isBlank()) {
                Alert.error = "Postal Code";
                Alert.blankEntryAlert();
                return;
            }
            if (customerPhone.isBlank()) {
                Alert.error = "Phone";
                Alert.blankEntryAlert();
                return;
            }
            if (countryCombo.getSelectionModel().isEmpty()) {
                Alert.error = "Country";
                Alert.blankEntryAlert();
                return;
            }
            if (divisionCombobox.getSelectionModel().isEmpty()) {
                Alert.error = "Division";
                Alert.blankEntryAlert();
                return;
            }
            int customerDivId = Division.lookupDivision(divisionCombobox.getValue().getDivName()).get(0).getDivID();

            DBCustomers.createCustomer(customerName, customerAddress, customerPostal,
                    customerPhone, createDate, createdBy, updatedDate, updatedBy, customerDivId);
            DBCustomers.getAllCustomers();

            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/customersMain.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Customers");
            stage.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method to select customers based on their country.
     * @param event not used
     */
    @FXML
    public void onActionCountryCBSelect(ActionEvent event) {
        Country selectedCountry = countryCombo.getValue();
        Predicate<Division> countrySel = selCountry -> selCountry.getCountryID() == countryCombo.getSelectionModel().getSelectedItem().getCountryID();
        ObservableList<Division> allDivisions = DBDivisions.getAllDivisions();
        FilteredList<Division> countryDivision = new FilteredList<>(allDivisions, countrySel);

        if(selectedCountry == null){
            countryDivision.setPredicate(null);
        }
        else{
            countryDivision.setPredicate(countrySel);
            divisionCombobox.setItems(countryDivision);
        }
    }

    /**
     * Initializes the New Customer Form.
     * Populates the Country combobox and Division combobox with the values from the Db queries from the countries and
     * first_level_divisions tables of the MySQL database.
     * @param url
     * The location used to resolve relative paths for the root object, or
     * {@code null} if the location is not known.
     *
     * @param resourceBundle
     * The resources used to localize the root object, or {@code null} if
     * the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Country> countries = DBCountries.getAllCountries();
        ObservableList<Division> divisions = DBDivisions.getAllDivisions();
        countryCombo.setItems(countries);
        divisionCombobox.setItems(divisions);

    }
}
