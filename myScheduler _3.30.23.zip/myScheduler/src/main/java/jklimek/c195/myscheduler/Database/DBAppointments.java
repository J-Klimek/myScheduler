package jklimek.c195.myscheduler.Database;

import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.models.Appointment;
import jklimek.c195.myscheduler.models.Customer;
import java.sql.*;
import java.time.LocalDateTime;

/**
 * Database CRUD class for Appointments.
 * @author James Klimek | WGU CS195 Student
 */
public abstract class DBAppointments {

    /**
     * Method to Get all appointments from the appointments table of the MySQL database.
     * @return ObservableList of Appointment objects
     */
    public static ObservableList<Appointment> getAllAppointments(){

        String getAllApptsSql = "SELECT Appointment_ID, Title, Description, Location, Type, " +
                "Start, End, Create_Date, Created_By, Last_Update, " +
                "Last_Updated_By, Customer_ID, User_ID, appointments.Contact_ID, Contact_Name " +
                "FROM appointments, contacts WHERE appointments.Contact_ID = contacts.Contact_ID";

        try {
            PreparedStatement ps = JDBConnection.getConnection().prepareStatement(getAllApptsSql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int appointmentID = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDesc = rs.getString("Description");
                String appointmentLoc = rs.getString("Location");
                String appointmentType = rs.getString("Type");
                LocalDateTime appointmentStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime appointmentEnd = rs.getTimestamp("End").toLocalDateTime();
                LocalDateTime appointmentCreateDate = rs.getTimestamp("Create_Date").toLocalDateTime();
                String appointmentCreator = rs.getString("Created_By");
                LocalDateTime appointmentLastUpdated = rs.getTimestamp("Last_Update").toLocalDateTime();
                int customerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");

                //create a new customer based on query result
                Appointment newAppt = new Appointment(appointmentID,appointmentTitle,appointmentDesc,appointmentLoc,appointmentType,appointmentStart,appointmentEnd,appointmentCreateDate,appointmentCreator,appointmentLastUpdated,customerID,userID,contactID,contactName);
                if(!Appointment.allAppointments.contains(newAppt)) {
                    Appointment.allAppointments.add(newAppt);  //add Appointment objects to allAppointments list
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Appointment.allAppointments;
    }

    /**
     * Method for inserting a new Appointment into the appointments table of the MySQL Database.
     * @param apptTitle  Title of appointment
     * @param apptDesc  Description of the appointment
     * @param apptLoc  Location of the appointment
     * @param apptType  Type of the appointment
     * @param apptStartLDT  Start date/time of the appointment
     * @param apptEndLDT  End date/time of the appointment
     * @param createDate  Date the appointment was created
     * @param createdBy  The user who created the appointment
     * @param apptLastUpdated  The most recent date/time the appointment was updated
     * @param apptLastUpdatedBy  The last user to update the appointment
     * @param customerID  Customer ID
     * @param userID  User ID
     * @param contactID  Contact ID
     */
    public static void createAppointment(String apptTitle, String apptDesc, String apptLoc, String apptType,
                                         LocalDateTime apptStartLDT, LocalDateTime apptEndLDT, LocalDateTime createDate,
                                         String createdBy, LocalDateTime apptLastUpdated, String apptLastUpdatedBy,
                                         int customerID, int userID, int contactID)
    {
        LocalDateTime startUTC = apptStartLDT;
        LocalDateTime endUTC = apptEndLDT;
        LocalDateTime createdUTC = createDate;
        LocalDateTime updatedUTC = apptLastUpdated;

        try{
            String createAppointmentSql = "INSERT INTO appointments VALUES(Null,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
            PreparedStatement psCreateCust = JDBConnection.getConnection().prepareStatement(createAppointmentSql, Statement.RETURN_GENERATED_KEYS);
            psCreateCust.setString(1, apptTitle);
            psCreateCust.setString(2, apptDesc);
            psCreateCust.setString(3, apptLoc);
            psCreateCust.setString(4, apptType);
            psCreateCust.setTimestamp(5, Timestamp.valueOf(startUTC));
            psCreateCust.setTimestamp(6, Timestamp.valueOf(endUTC));
            psCreateCust.setTimestamp(7, Timestamp.valueOf(createdUTC));
            psCreateCust.setString(8, createdBy);
            psCreateCust.setTimestamp(9, Timestamp.valueOf(updatedUTC));
            psCreateCust.setString(10, apptLastUpdatedBy);
            psCreateCust.setInt(11, customerID);
            psCreateCust.setInt(12, userID);
            psCreateCust.setInt(13, contactID);

            psCreateCust.executeUpdate();
            ResultSet rs = psCreateCust.getGeneratedKeys();
            rs.next();
            int apptID = rs.getInt(1);

        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

    /**
     * Method for updating an existing Appointment in the appointments table of the MySQL Database.
     * @param apptID  ID of the appointment
     * @param apptTitle  Title of the appointment
     * @param apptDesc  Description  of the appointment
     * @param apptLoc  Location  of the appointment
     * @param apptType  Type of the appointment
     * @param apptStartLDT  Start date/time of the appointment
     * @param apptEndLDT  End date/time of the appointment
     * @param createDate  Date the appointment was originally created
     * @param createdBy  User that originally created the appointment
     * @param apptLastUpdated  Date/time the appointment was last updated
     * @param apptLastUpdatedBy  User that last updated the appointment
     * @param customerID  Customer ID
     * @param userID  User ID
     * @param contactID  Contact ID
     */
    public static void updateAppointment(int apptID, String apptTitle, String apptDesc, String apptLoc, String apptType,
                                         LocalDateTime apptStartLDT, LocalDateTime apptEndLDT,
                                         LocalDateTime createDate, String createdBy, LocalDateTime apptLastUpdated,
                                         String apptLastUpdatedBy, int customerID, int userID, int contactID)
    {
        try {
            String updateApptSql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, " +
                    "Type = ?, Start = ?, End = ?, Create_Date = ?, Created_By = ?, Last_Update = ?, " +
                    "Last_Updated_By = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
            PreparedStatement psUpdateAppt = JDBConnection.getConnection().prepareStatement(updateApptSql);
            psUpdateAppt.setString(1, apptTitle);
            psUpdateAppt.setString(2, apptDesc);
            psUpdateAppt.setString(3, apptLoc);
            psUpdateAppt.setString(4, apptType);
            psUpdateAppt.setTimestamp(5, Timestamp.valueOf(apptStartLDT));
            psUpdateAppt.setTimestamp(6, Timestamp.valueOf(apptEndLDT));
            psUpdateAppt.setTimestamp(7, Timestamp.valueOf(createDate));
            psUpdateAppt.setString(8, createdBy);
            psUpdateAppt.setTimestamp(9, Timestamp.valueOf(apptLastUpdated));
            psUpdateAppt.setString(10, apptLastUpdatedBy);
            psUpdateAppt.setInt(11, customerID);
            psUpdateAppt.setInt(12, userID);
            psUpdateAppt.setInt(13, contactID);
            psUpdateAppt.setInt(14,apptID);

            psUpdateAppt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to delete an appointment from the appointments table in the MySQL database.
     * @param selectedAppointment  Appointment object passed in from the selection in the Appointments TableView
     */
    public static void deleteAppointment(Appointment selectedAppointment) {
        try {

            String deleteAppointmentSql = "DELETE FROM appointments WHERE Appointment_ID = " + selectedAppointment.getApptID();
            PreparedStatement psDeleteSelAppt = JDBConnection.getConnection().prepareStatement(deleteAppointmentSql);
            psDeleteSelAppt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to delete an appointment for a specific Customer.
     * Deletes an appointment from the appointments table in the MySQL database Where the customer ID matches the selected Customer.
     * @param selectedCustomer selectedCustomer
     */
    public static void deleteCustomersAppointments(Customer selectedCustomer) {
        try {

            String deleteAppointmentSql = "DELETE FROM appointments WHERE Customer_ID = " + selectedCustomer.getCustomerID();
            PreparedStatement psDeleteSelAppt = JDBConnection.getConnection().prepareStatement(deleteAppointmentSql);
            psDeleteSelAppt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
