package jklimek.c195.myscheduler.models;

import javafx.scene.control.ButtonType;
import jklimek.c195.myscheduler.controllers.AppointmentsController;
import jklimek.c195.myscheduler.controllers.LoginFormController;
import java.time.LocalTime;
import java.util.ResourceBundle;

/**
 * Alert Class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class Alert {
    //static attributes and methods for Alert pop-ups
    public static javafx.scene.control.Alert emptyField = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidTitle = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidDescription = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidLocation = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidType = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidLogin= new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.WARNING);
    public static javafx.scene.control.Alert invalidSelection = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert confirmDelete = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION);
    public static javafx.scene.control.Alert confirmSave = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION);
    public static javafx.scene.control.Alert confirmLogout = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION);
    public static javafx.scene.control.Alert confirmExit = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION);
    public static javafx.scene.control.Alert noApptsThisMonth = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
    public static javafx.scene.control.Alert noApptsThisWeek = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
    public static javafx.scene.control.Alert noCustomerAppts = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
    public static javafx.scene.control.Alert noContactAppts = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
    public static javafx.scene.control.Alert successfulCustomerDelete = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
    public static javafx.scene.control.Alert outsideBusinessHours = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidTimeSelection = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidNullDateTime = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidCustomerID = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidUserID = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert invalidContactID = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert overlapAppointment = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
    public static javafx.scene.control.Alert upcomingAppointment = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
    public static javafx.scene.control.Alert noUpcomingAppointments = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
    public static String error = "";
    private static final ResourceBundle alertRb = LoginFormController.getRb();
    static ButtonType OKfr = new ButtonType(alertRb.getString("OK"));
    private static Customer selectedCustomer = null;
    private static Appointment selectedAppointment = AppointmentsController.getSelectedAppointment();
    private static Contact selectedContact = null;

    /**
     * Static method implementing the Invalid Login ERROR.
     * Incorrect username or password.
     */
    public static void invalidLoginAlert(){
        invalidLogin.setTitle(alertRb.getString("Failed") + " " + alertRb.getString("Login"));
        invalidLogin.setHeaderText(alertRb.getString("Unauthorized User") + "! - " + alertRb.getString("Access Denied"));
        invalidLogin.setContentText(alertRb.getString("Invalid") + " " + alertRb.getString("Username") + " " +
                alertRb.getString("or") + " " + alertRb.getString("Password"));
        invalidLogin.getButtonTypes().set(0,OKfr);
        invalidLogin.show();
    }
    /**
     * Static method implementing the upcoming appointment alert.
     * Alerts if an appointment is starting within 15 minutes of logging in.
     * @param appointment Appointment Object
     */
    public static void upcomingAppointmentAlert(Appointment appointment) {
        upcomingAppointment.setTitle("Upcoming Appointment");
        upcomingAppointment.setHeaderText("Appointment starting within the next 15 minutes.");
        upcomingAppointment.setContentText("Appointment ID: " + appointment.getApptID() + "\nDate and Time: " + appointment.getApptStart().format(AppointmentsController.getFormatterDT()));
        upcomingAppointment.show();
    }
    /**
     * Static method implementing the no upcoming appointments alert.
     * User does not have any upcoming appointments.
     */
    public static void noUpcomingAppointmentsAlert() {
        noUpcomingAppointments.setTitle("Upcoming Appointment");
        noUpcomingAppointments.setHeaderText("No upcoming appointments.");
        noUpcomingAppointments.setContentText("You do not have any scheduled appointments that start within the next 15 minutes.");
        noUpcomingAppointments.show();
    }
    /**
     * Static method implementing the no appointments this month alert.
     * No appointments for the current month so it defaults back to all appointments.
     */
    public static void noApptsMonthAlert() {
        noApptsThisMonth.setTitle("Appointment Information");
        noApptsThisMonth.setHeaderText("No Appointments this month");
        noApptsThisMonth.setContentText("Showing All scheduled Appointments.");
        noApptsThisMonth.show();
    }
    /**
     * Static method implementing the no appointments this week alert.
     * No appointments for the current week so it defaults back to all appointments.
     */
    public static void noApptsWeekAlert() {

        noApptsThisWeek.setTitle("Appointment Information");
        noApptsThisWeek.setHeaderText("No Appointments this week");
        noApptsThisWeek.setContentText("Showing All scheduled Appointments.");
        noApptsThisWeek.show();
    }
    /**
     * Static method implementing the no appointments for customer alert.
     * Customer name + does not have any scheduled appointments.
     * @param selectedCustomer Customer Object
     */
    public static void noApptsForCustomerAlert(Customer selectedCustomer) {

        noCustomerAppts.setTitle("Appointment Information");
        noCustomerAppts.setHeaderText("No Appointments");
        noCustomerAppts.setContentText(selectedCustomer.getCustomerName() + " does not have any scheduled appointments.");
        noCustomerAppts.show();
    }
    /**
     * Static method implementing the no appointments for contact alert.
     * Contact name + does not have any scheduled appointments.
     * @param selectedContact Contact Object
     */
    public static void noApptsForContactAlert(Contact selectedContact) {
        noContactAppts.setTitle("Appointment Information");
        noContactAppts.setHeaderText("No Appointments");
        noContactAppts.setContentText(selectedContact.getContactName() + " does not have any scheduled appointments.");
        noContactAppts.show();
    }
    /**
     * Static method implementing the Invalid selection message ERROR.
     * Nothing was selected.
     */
    public static void invalidSelectionAlert() {
        invalidSelection.setTitle("Invalid Selection");
        invalidSelection.setContentText("Nothing Selected, please select a row and try again.");
        invalidSelection.show();
    }
    /**
     * Static method implementing the Invalid entry message ERROR.
     * field cannot be blank.
     */
    public static void blankEntryAlert(){
        emptyField.setTitle("Invalid " + error);
        emptyField.setContentText(error + " field cannot be blank.");
        emptyField.show();
    }
    /**
     * Static method to pop up a confirmation window when attempting to delete.
     * Asks the user to confirm delete.
     * @param customer Customer Object
     */
    public static void confirmDeleteCustomerAlert(Customer customer){
        confirmDelete.setTitle("DELETE Confirmation");
        confirmDelete.setHeaderText("DELETE Customer: " + customer.getCustomerName());
        confirmDelete.setContentText("Are you sure you want to DELETE this customer?");
    }
    /**
     * Static method implementing the successful customer delete alert.
     * customer was successfully deleted.
     * @param customer Customer Object
     */
    public static void setSuccessfulCustomerDeleteAlert(Customer customer){
        successfulCustomerDelete.setTitle("SUCCESS!");
        successfulCustomerDelete.setHeaderText(customer.getCustomerName() + " has been successfully deleted.");
        successfulCustomerDelete.setContentText("If " + customer.getCustomerName() +
                " had any appointments, they have been cancelled.");
        successfulCustomerDelete.show();
    }
    /**
     * Static method to pop up a confirmation window when attempting to delete an appointment.
     * Asks the user to confirm delete.
     * @param appointment Appointment Object
     */
    public static void confirmDeleteAppointmentAlert(Appointment appointment){
        confirmDelete.setTitle("DELETE Appointment Confirmation");
        confirmDelete.setHeaderText("DELETE Appointment ID: " + appointment.getApptID());
        confirmDelete.setContentText("Are you sure you want to DELETE this appointment?");
    }
    /**
     * Static method to pop up a confirmation window when attempting to delete all appointments for a customer.
     * Asks the user to confirm delete.
     * @param customer Customer Object
     */
    public static void confirmDeleteCustomerApptsAlert(Customer customer){
        confirmDelete.setTitle("DELETE Appointments Confirmation");
        confirmDelete.setContentText(customer.getCustomerName() +  " has scheduled appointments. Deleting "
                + customer.getCustomerName() + " from Customers, will also DELETE ALL associated appointments." +
                "\n\nAre you sure you want to DELETE?");
    }
    /**
     * Static method implementing the outside business hours message ERROR.
     * Appointment start or end time are outside business hours.
     * @param ltStart 8 AM Local Time
     * @param ltEnd 10 PM Local Time
     */
    public static void outsideBusinessHoursAlert(LocalTime ltStart, LocalTime ltEnd){
        outsideBusinessHours.setTitle("Invalid Appointment Time");
        outsideBusinessHours.setContentText(ltStart.format(AppointmentsController.getFormatterT()) + " - " + ltEnd.format(AppointmentsController.getFormatterT()) +  " is outside of business hours.\nBusiness Hours are 8:00AM EST - 10:00PM EST\nPlease select a new time between 8AM-10PM ET");
        outsideBusinessHours.show();
    }
    /**
     * Static method to pop up a confirmation window when attempting to close the program.
     * Asks the user to confirm closing the program.
     */
    public static void confirmLogoutAlert(){
        confirmLogout.setTitle("Logout");
        confirmLogout.setContentText("Would you like to sign out of myScheduler?");
    }
    /**
     * Static method to pop up a confirmation window when attempting to close the program.
     * Asks the user to confirm closing the program.
     */
    public static void confirmExitAlert(){
        confirmExit.setTitle("Exit Program");
        confirmExit.setContentText("Would you like to close the program?");
    }
    /**
     * Static method implementing the invalid time selection message ERROR.
     * End time cannot be before the start time.
     */
    public static void invalidTimeSelectionAlert() {
        invalidTimeSelection.setTitle("Invalid Time Selection");
        invalidTimeSelection.setContentText("Appointment end time cannot be before the appointment start time.\nPlease select a new time.");
        invalidTimeSelection.show();
    }
    /**
     * Static method implementing the Invalid title message ERROR.
     * Appointment title cannot be blank.
     */
    public static void invalidTitleAlert() {
        invalidTitle.setTitle("Invalid Title");
        invalidTitle.setContentText("Appointment title cannot be blank.");
        invalidTitle.show();
    }
    /**
     * Static method implementing the Invalid description message ERROR.
     * Appointment description cannot be blank.
     */
    public static void invalidDescriptionAlert() {
        invalidDescription.setTitle("Invalid Description");
        invalidDescription.setContentText("Appointment description cannot be blank.");
        invalidDescription.show();
    }
    /**
     * Static method implementing the Invalid location message ERROR.
     * Apppointment location cannot be blank.
     */
    public static void invalidLocationAlert() {
        invalidLocation.setTitle("Invalid Location");
        invalidLocation.setContentText("Appointment location cannot be blank.");
        invalidLocation.show();
    }
    /**
     * Static method implementing the Invalid Type message ERROR.
     * Appointment type cannot be blank.
     */
    public static void invalidTypeAlert() {
        invalidType.setTitle("Invalid Type");
        invalidType.setContentText("Appointment type cannot be blank.");
        invalidType.show();
    }
    /**
     * Static method implementing the Invalid Date/Time message ERROR.
     * Appointment date/time cannot be blank.
     */
    public static void invalidNullDateTimeAlert() {
        invalidNullDateTime.setTitle("Invalid Date");
        invalidNullDateTime.setContentText("Missing a start date/time or end date/time.\nPlease select a start date/time and an end date/time.");
        invalidNullDateTime.show();
    }
    /**
     * Static method implementing the Invalid customerID message ERROR.
     * CustomerID cannot be blank.
     */
    public static void invalidCustomerIDAlert() {
        invalidCustomerID.setTitle("Invalid Customer ID");
        invalidCustomerID.setContentText("Customer ID cannot be blank.\nPlease select a customer.");
        invalidCustomerID.show();
    }
    /**
     * Static method implementing the Invalid userID message ERROR.
     * UserID cannot be blank.
     */
    public static void invalidUserIDAlert() {
        invalidUserID.setTitle("Invalid User ID");
        invalidUserID.setContentText("User ID cannot be blank.\nPlease select a customer.");
        invalidUserID.show();
    }
    /**
     * Static method implementing the Invalid contactID message ERROR.
     * ContactID cannot be blank.
     */
    public static void invalidContactIDAlert() {
        invalidContactID.setTitle("Invalid Contact ID");
        invalidContactID.setContentText("Contact ID cannot be blank.\nPlease select a customer.");
        invalidContactID.show();
    }
    /**
     * Static method implementing the overlapping appointment message ERROR.
     * Appointment date/time conflicts with an existing appointment for the Customer.
     */
    public static void overlappingAppointmentAlert() {
        overlapAppointment.setTitle("Appointment Overlap");
        overlapAppointment.setContentText("Selected date/time conflicts with an existing appointment.\nPlease choose a new date/time.");
        overlapAppointment.show();
    }

}
