package jklimek.c195.myscheduler.models;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * User Class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class User {
    private int userID;
    private String userName;
    private String userPassword;

    private static User signedInUser = null;
    public static ObservableList<User> allUsers = FXCollections.observableArrayList();
    /**
     * Default Constructor for User Objects.
     * @param userID User ID
     */
    public User(int userID){
        this.userID = userID;
    }

    /**
     * Constructor for User Objects with Username and password.
     * @param userName User Name
     * @param userPassword User Password
     */
    public User(String userName, String userPassword){
        this.userName = userName;
        this.userPassword = userPassword;
    }

    /**
     * Constructor for User Objects with User ID, User Name and Password.
     * @param userID User ID
     * @param userName User Name
     * @param userPassword User Password
     */
    public User(int userID, String userName, String userPassword)
    {
        this.userID = userID;
        this.userName = userName;
        this.userPassword = userPassword;
    }

    /**
     * Method to Get the User ID
     * @return int User ID
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Method to Get the User Name.
     * @return String User Name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Static Method to Get Signed-in User.
     * @return User Object signedInUser
     */
    public static User getSignedInUser() {
        return signedInUser;
    }

    /**
     * Static Method to Set the Signed-in User.
     * @param signedInUser User Object signedInUser
     */
    public static void setSignedInUser(User signedInUser) {
        User.signedInUser = signedInUser;
    }

    /**
     * Override Method of the toString() method.
     * Override toString() to allow proper formatting in combo boxes.
     * @return String User ID
     */
    @Override
    public String toString(){
        return "" + userID;
    }

    /**
     * Override Method of the equals() method.
     * Override equals() to allow comparing new Objects created from DB query
     * to existing ObservableList to avoid duplicates.
     * @param user Object user
     * @return false if null or not equal, else true.
     */
    @Override
    public boolean equals(Object user) {
        if (user == null || getClass() != user.getClass()) {
            return false;
        }
        return this.userID == ((User) user).userID;
    }

    /**
     * Override Method of the hashCode() method.
     * Override hashCode() to allow comparing new Objects created from DB query to existing ObservableList to avoid duplicates
     * @return User ID
     */
    @Override
    public int hashCode(){
        return userID;
    }
}

