package jklimek.c195.myscheduler.Database;

import jklimek.c195.myscheduler.models.Password;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 * JDBC Class.
 */
public abstract class JDBConnection {

    private static final String protocol = "jdbc";
    private static final String vendor = ":mysql:";
    private static final String location = "//localhost/";
    private static final String dbName = "client_schedule";
    private static final String jdbURL = protocol + vendor + location + dbName + "?connectionTimeZone = SERVER";
    private static final String MySQLDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUserName = "sqlUser";
    private static final String dbPassword = Password.getPassword();
    public static Connection connection;

    /**
     * Method to establish a connection with the MySQL database.
     */
    public static void openConnection()
    {
        try {
            Class.forName(MySQLDriver);
            connection = DriverManager.getConnection(jdbURL, dbUserName, dbPassword);
            System.out.println("Connection to database successful");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to Get the connection.
     * @return connection
     */
    public static Connection getConnection(){
        return connection;
    }

    /**
     * Method to close the connection to the MySQL database.
     */
    public static void closeConnection()
    {
        try{
            connection.close();
            System.out.println("Connection to database has been closed.");
        }catch (Exception e) {
            //do nothing
        }
    }
}
