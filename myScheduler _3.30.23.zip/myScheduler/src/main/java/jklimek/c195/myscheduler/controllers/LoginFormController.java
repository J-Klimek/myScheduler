package jklimek.c195.myscheduler.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.DBUsers;
import jklimek.c195.myscheduler.Database.JDBConnection;
import jklimek.c195.myscheduler.models.Alert;
import jklimek.c195.myscheduler.models.Appointment;
import jklimek.c195.myscheduler.models.User;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import java.io.*;

/**
 * Controller class for the Login Form.
 * @author James Klimek | WGU CS195 Student
 *
 */
public class LoginFormController implements Initializable {
    Stage stage;
    Parent scene;
    static ResourceBundle rb = ResourceBundle.getBundle("/resource_bundles/ResourceBundle", Locale.getDefault());
    String loginAttempt = "";

    @FXML
    private Label timeZoneLabel;
    @FXML
    private Label signInLabel;

    @FXML
    private Button closeBtn;

    @FXML
    private Label languageLabel;

    @FXML
    private Label locationLabel;

    @FXML
    private Label logInLangTxt;

    @FXML
    private Text loginFormTitleLabel;

    @FXML
    private Label passwordLabel;

    @FXML
    private PasswordField pwdTxt;

    @FXML
    private Button signInBtn;

    @FXML
    private TextField userNameTxt;

    @FXML
    private Label usernameLabel;

    /**
     *  Method for opening the Appointments form.
     *  This method takes the user to the Appointments screen of the program.
     *  It will trigger one of the upcoming appointment alerts.
     *  @param event action event
     */
    @FXML
    public void OnActionOpenAppointments(ActionEvent event){
        String userName = userNameTxt.getText();
        String password = pwdTxt.getText();
        User userToVerify = new User(userName,password);
        boolean verifiedUser = DBUsers.verifyUser(userName,password);

        try {
            if (!verifiedUser) {
                Alert.invalidLoginAlert();
                loginAttempt = ("Timestamp:" + LocalDateTime.now().format(AppointmentsController.getFormatterDT()) + "\t" + "|\tFAILED sign in attempt For username: " + userToVerify.getUserName());
                logUserActivity(loginAttempt);
            } else {
                User.setSignedInUser(userToVerify);
                loginAttempt = ("Timestamp:" + LocalDateTime.now().format(AppointmentsController.getFormatterDT()) + "\t" + "|\tSUCCESSFUL sign in for username: " + userToVerify.getUserName());
                logUserActivity(loginAttempt);
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/FXML/AppointmentsMainForm.fxml"));
                stage.setScene(new Scene(scene));
                stage.setTitle("Appointments");
                stage.show();
                //Check for appointments in the next 15 minutes from local time
                for (Appointment appt : Appointment.allAppointments) {
                    if (appt.getApptStart().isBefore(LocalDateTime.now().plusMinutes(15)) && appt.getApptEnd().isAfter(LocalDateTime.now())) {
                        Alert.upcomingAppointmentAlert(appt);
                    } else {
                        Alert.noUpcomingAppointmentsAlert();
                    }
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method for closing the program.
     * Closes the database connection and closes the program.
     * @param event not used
     */
    @FXML
    public void OnActionCloseProgram(ActionEvent event){
        Alert.confirmExitAlert();
        Optional<ButtonType> result = Alert.confirmExit.showAndWait();
        if(result.get() == ButtonType.OK) {
            JDBConnection.closeConnection();
            System.exit(0);
        }
    }
    /**
     * Gets ResourceBundle Rb.
     * Rb ResourceBundle is for Locale translations
     * @return rb
     */
    public static ResourceBundle getRb() {
        return rb;
    }

    /**
     * Method for logging user login attempts.
     * Creates a BufferedWriter, FileWriter for file name login_activity.txt and writes each
     * new entry to a new line.
     * @param loginAttempt String statement of successful or failed login attempt with username and date/time
     */
    public void logUserActivity(String loginAttempt){
        try(BufferedWriter bw = new BufferedWriter(new FileWriter("login_activity.txt", true))){
            bw.write(loginAttempt);
            bw.newLine();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    /**
     * Initializes the LoginForm Controller.
     * Sets the displayed text on the login form to the Language according to the users OS settings.
     * Also sets the location to the user's OS local timezone.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        DBUsers.getAllUsers();
        logInLangTxt.setText(Locale.getDefault().getDisplayLanguage());
        locationLabel.setText(String.valueOf(ZoneId.systemDefault()));

        if(Locale.getDefault().getLanguage().equals("fr")){
            loginFormTitleLabel.setText(rb.getString("myScheduler"));
            signInLabel.setText(rb.getString("Sign In") + ":");
            usernameLabel.setText(rb.getString("Username") + ":");
            passwordLabel.setText(rb.getString("Password") + ":");
            signInBtn.setText(rb.getString("Sign In"));
            closeBtn.setText(rb.getString("Close"));
            timeZoneLabel.setText(rb.getString("Time zone"));
            locationLabel.setText(rb.getString("Current Location"));
            languageLabel.setText(rb.getString("Current Language"));
        }
    }
}