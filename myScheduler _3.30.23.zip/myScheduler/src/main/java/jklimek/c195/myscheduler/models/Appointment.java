package jklimek.c195.myscheduler.models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.Database.DBAppointments;
import java.time.LocalDateTime;

/**
 * Appointment class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class Appointment {

    int apptID;
    String apptTitle;
    String apptDesc;
    String apptLoc;
    String apptType;
    LocalDateTime apptStart;
    LocalDateTime apptEnd;
    LocalDateTime apptCreateDate;
    String apptCreatedBy;
    LocalDateTime apptLastUpdate;
    String apptLastUpdatedBy;
    int customerID;
    int userID;
    int contactID;
    String contactName;
    public static ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();

    /**
     * Default Constructor for Appointment Objects.
     */
    public Appointment(){}
    /**
     * Constructor for Appointment Objects for inserting into the MySQL database.
     * @param apptID Appointment ID
     * @param apptTitle Appointment Title
     * @param apptDesc Appointment Description
     * @param apptLoc Appointment Location
     * @param apptType Appointment Type
     * @param apptStart Appointment Start date/time
     * @param apptEnd Appointment End date/time
     * @param apptCreateDate Date the appointment was originally created
     * @param apptCreatedBy User that created the appointment
     * @param apptLastUpdate Date/time the appointment was last updated
     * @param apptLastUpdatedBy User that last updated the appointment
     * @param customerID Customer ID
     * @param contactID Contact ID
     */
    public Appointment(int apptID, String apptTitle, String apptDesc, String apptLoc, String apptType,
                       LocalDateTime apptStart, LocalDateTime apptEnd, LocalDateTime apptCreateDate,
                       String apptCreatedBy, LocalDateTime apptLastUpdate, String apptLastUpdatedBy,
                       int customerID, int contactID)
    {
        this.apptID = apptID;
        this.apptTitle = apptTitle;
        this.apptDesc = apptDesc;
        this.apptLoc = apptLoc;
        this.apptType = apptType;
        this.apptStart = apptStart;
        this.apptEnd = apptEnd;
        this.apptCreateDate = apptCreateDate;
        this.apptCreatedBy = apptCreatedBy;
        this.apptLastUpdate = apptLastUpdate;
        this.apptLastUpdatedBy = apptLastUpdatedBy;
        this.customerID = customerID;
        this.contactID = contactID;
    }

    /**
     * Constructor for Appointment Objects in a format for Appointment Form tableview.
     * @param appointmentID Appointment ID
     * @param appointmentTitle Appointment Title
     * @param appointmentDesc Appointment Description
     * @param appointmentLoc Appointment Location
     * @param appointmentType Appointment Type
     * @param appointmentStart Appointment start date/time
     * @param appointmentEnd Appointment end date/time
     * @param appointmentCreateDate Date/time the appointment was originally created
     * @param appointmentCreator User that created the appointment
     * @param appointmentLastUpdated Date/time the appointment was last updated
     * @param customerID Customer ID
     * @param userID User ID
     * @param contactID Contact ID
     * @param contactName Contact Name
     */
    public Appointment(int appointmentID, String appointmentTitle, String appointmentDesc, String appointmentLoc,
                String appointmentType, LocalDateTime appointmentStart,LocalDateTime appointmentEnd, LocalDateTime appointmentCreateDate,
                String appointmentCreator, LocalDateTime appointmentLastUpdated, int customerID,
                int userID, int contactID, String contactName)
    {
        this.apptID = appointmentID;
        this.apptTitle = appointmentTitle;
        this.apptDesc = appointmentDesc;
        this.apptLoc = appointmentLoc;
        this.apptType = appointmentType;
        this.apptStart = appointmentStart;
        this.apptEnd = appointmentEnd;
        this.apptCreateDate = appointmentCreateDate;
        this.apptCreatedBy = appointmentCreator;
        this.apptLastUpdate = appointmentLastUpdated;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
        this.contactName = contactName;
    }

    /**
     * Method to Get the Appointment ID.
     * @return int Appointment ID
     */
    public int getApptID() {
        return apptID;
    }

    /**
     * Method to Get the Appointment Title.
     * @return String Appointment Title
     */
    public String getApptTitle() {
        return apptTitle;
    }

    /**
     * Method to Get the Appointment Description.
     * @return String Appointment Description
     */
    public String getApptDesc() {
        return apptDesc;
    }

    /**
     * Method to Get Appointment Location.
     * @return String Appointment Location
     */
    public String getApptLoc() {
        return apptLoc;
    }

    /**
     * Method to Get Appointment Type.
     * @return Appointment Type
     */
    public String getApptType() {
        return apptType;
    }

    /**
     * Method to Get the Appointment Start Date/Time.
     * Gets the Appointment Start date/time in the user's local timezone.
     * @return LocalDateTime Appointment Start Date/Time
     */
    public LocalDateTime getApptStart() {
        return apptStart;
    }

    /**
     * Method to Get the Appointment End Date/Time.
     * Gets the Appointment End date/time in the user's local timezone.
     * @return LocalDateTime Appointment End Date/Time
     */
    public LocalDateTime getApptEnd() {
        return apptEnd;
    }

    /**
     * Method to Get the Date/Time the Appointment was created.
     * Gets the created date/time in the user's local timezone.
     * @return LocalDateTime Appointment Create Date
     */
    public LocalDateTime getApptCreateDate() {
        return apptCreateDate;
    }

    /**
     * Method to Get the User ID of the User that created the Appointment.
     * @return String User ID of the Appointment creator
     */
    public String getApptCreatedBy() {
        return apptCreatedBy;
    }

    /**
     * Method to Get the Customer ID.
     * @return int Customer ID
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * Method to Get the UserID.
     * @return int User ID
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Method to Get the Contact ID.
     * @return int Contact ID
     */
    public int getContactID() {
        return contactID;
    }

    /**
     * Method to Get the Contact Name.
     * @return String Contact Name
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Static Method to Get the ObservableList of All Appointments.
     * @return ObservableList allAppointments
     */
    public static ObservableList<Appointment> getAllAppointments() {
        return allAppointments;
    }

    /**
     * Static Method to Update the Appointment Object in the ObservableList allAppointments.
     * @param indexOf Appointment Object to update
     * @param updatedAppointment Updated Appointment object to replace the existing Appointment Object
     */
    public static void updateAppointment(int indexOf, Appointment updatedAppointment) {
        Appointment.allAppointments.set(indexOf, updatedAppointment);
    }
    /**
     * Static method that passes in an Appointment object to be deleted.
     * Triggers Alert pop-up if selectedAppointment parameter is null.
     * @param selectedAppointment Appointment object to be deleted.
     * @return False if selectedAppointment is null else True.
     */
    public static boolean deleteAppointment(Appointment selectedAppointment) {
        if(selectedAppointment == null){
            Alert.invalidSelectionAlert();
            return false;
        }
        else{
            return true;
        }
    }

    /**
     * Static Method to Look up an Appointment by the appointment ID.
     * Creates a new ObservableList of 1 appointment by searching for the passed in appointment ID in a list of
     * all appointments pulled from the MySQL database.
     * @param apptID Appointment ID to search for
     * @return ObservableList of one appointment that matches the appointment id parameter
     */
    public static ObservableList<Appointment> lookupAppt(int apptID) {
        ObservableList<Appointment> namedAppointments = FXCollections.observableArrayList();
        ObservableList<Appointment> allAppointments = DBAppointments.getAllAppointments();
        for (Appointment a : allAppointments) {
            if (a.getApptID() == apptID) {
                namedAppointments.add(a);
            }
        }
        return namedAppointments;
    }

    /**
     * Override Method for the equals() method.
     * Override equals() to allow comparing new Objects created from DB query to existing ObservableList to avoid duplicates.
     * @param appointment Appointment object
     * @return Appointment Object's appointment ID
     */
    @Override
    public boolean equals(Object appointment) {
        if (appointment == null || getClass() != appointment.getClass()) {
            return false;
        }
        return this.apptID == ((Appointment) appointment).apptID;
    }

    /**
     * Override Method for the hashCode() method.
     * Override hashCode() to allow comparing new Objects created from DB query to existing ObservableList to avoid duplicates.
     * @return Appointment ID
     */
    @Override //
    public int hashCode(){
        return apptID;
    }
}
