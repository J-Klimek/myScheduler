package jklimek.c195.myscheduler.models;

/**
 * Password Class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class Password {
    static String password = "Passw0rd!";

    /**
     * Default Constructor for Password Objects.
     */
    public Password(){
        this.password = "Passw0rd!";
    }

    /**
     * Method to Get Password.
     * @return String Password
     */
    public static String getPassword() {
        return password;
    }
}
