package jklimek.c195.myscheduler.Database;


import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.models.Country;
import java.sql.*;

/**
 * Database Access class for Countries.
 * @author James Klimek | WGU CS195 Student
 */
public class DBCountries {
    /**
     * Method to Get all countries from the countries table of the MySQL database.
     * @return ObservableList of Country objects
     */
    public static ObservableList<Country> getAllCountries(){

        try{
            String sqlQuery = "SELECT * from countries";
            PreparedStatement ps = JDBConnection.getConnection().prepareStatement(sqlQuery);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int countryID = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");
                Country country = new Country(countryID, countryName);

                if(!Country.countryList.contains(country)) {
                    Country.countryList.add(country);
                }
            }
        }catch(SQLException throwables){
            throwables.printStackTrace();
        }
        return Country.countryList;
    }
}
