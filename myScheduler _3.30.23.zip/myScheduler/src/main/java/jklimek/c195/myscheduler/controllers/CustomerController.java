package jklimek.c195.myscheduler.controllers;


import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.DBAppointments;
import jklimek.c195.myscheduler.Database.DBCustomers;
import jklimek.c195.myscheduler.models.Alert;
import jklimek.c195.myscheduler.models.Appointment;
import jklimek.c195.myscheduler.models.Customer;
import jklimek.c195.myscheduler.models.User;
import java.util.stream.Collectors;

/**
 * Controller class for Customers.
 * @author James Klimek | WGU CS195 Student
 */
public class CustomerController implements Initializable {
    Stage stage;
    Parent scene;
    private static Customer selectedCustomer = null;

    @FXML
    private TableView<Customer> CustomersTableView;
    @FXML
    private TableColumn<Customer, Integer> custIDCol;
    @FXML
    private TableColumn<Customer, String> custNameCol;
    @FXML
    private TableColumn<Customer, String> custAddressCol;
    @FXML
    private TableColumn<Customer, String> custPhoneCol;
    @FXML
    private TableColumn<Customer, String> custPostalCodeCol;
    @FXML
    private TableColumn<Customer, String> custCountryCol;
    @FXML
    private TableColumn<Customer, String> custStateProvCol;
    @FXML
    private TableColumn<Customer, Integer> custDivIDCol;
    @FXML Label custSignedInUserTxt;

    /**
     * Method to delete a customer object.
     * Method streams a list of all appointments and filters to a new list based on the customerID of the selected customer.
     * Lambda used here for ease of iteration and filtering of the Collection.
     * @param event not used
     */
    @FXML
    public void OnActionDeleteCustomer(ActionEvent event) {
        Customer customerToDel = CustomersTableView.getSelectionModel().getSelectedItem();
        boolean delCustomer = false;
        delCustomer = Customer.deleteCustomer(customerToDel);
        List<Appointment> apptByCustomer = Appointment.allAppointments.stream()
                .filter(appt -> appt.getCustomerID() == customerToDel.getCustomerID())
                .collect(Collectors.toList());

        while(delCustomer){
            Alert.confirmDeleteCustomerAlert(customerToDel);
            Optional<ButtonType> result = Alert.confirmDelete.showAndWait();
            if (result.get() == ButtonType.OK){
                if(!apptByCustomer.isEmpty()) {
                    Alert.confirmDeleteCustomerApptsAlert(customerToDel);
                    result = Alert.confirmDelete.showAndWait();
                    if(result.get() == ButtonType.OK){
                        DBAppointments.deleteCustomersAppointments(customerToDel);
                    }
                    else{
                        break;
                    }
                    Customer.allCustomers.remove(customerToDel);
                    DBCustomers.deleteCustomer(customerToDel);
                    Alert.setSuccessfulCustomerDeleteAlert(customerToDel);
                    break;
                }
                else {
                    Customer.allCustomers.remove(customerToDel);
                    DBCustomers.deleteCustomer(customerToDel);
                    Alert.setSuccessfulCustomerDeleteAlert(customerToDel);
                    break;
                }
            }
            else{
                break;
            }
        }
    }
    /**
     * Method to pop up a confirmation window when attempting to log out of the program.
     * Asks the user to confirm Logging out. Returns the user to the Log in screen.
     * @param event action event
     */
    @FXML
    public void OnActionLogout(ActionEvent event){
        try {
            Alert.confirmLogoutAlert();
            Optional<ButtonType> result = Alert.confirmLogout.showAndWait();
            if(result.get() == ButtonType.OK) {
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/FXML/LoginForm.fxml"));
                stage.setScene(new Scene(scene));
                stage.setTitle(LoginFormController.getRb().getString("myScheduler") + " " + LoginFormController.getRb().getString("Login"));
                stage.show();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     *  Method for opening the Appointments form.
     * @param event action event
     */
    @FXML
    public void OnActionOpenAppointments(ActionEvent event){
        try {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/AppointmentsMainForm.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Appointments");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     *  Method for opening the Reports form.
     * @param event action event
     */
    @FXML
    public void OnActionOpenReports(ActionEvent event){
        try{
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/FXML/reportForm.fxml"));
        stage.setScene(new Scene(scene));
        stage.setTitle("Reports");
        stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     *  Method for opening the create new customer form.
     * @param event action event
     */
    @FXML
    public void OnActionOpenNewCustomer(ActionEvent event){
        try{
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/FXML/newCustomerForm.fxml"));
        stage.setScene(new Scene(scene));
        stage.setTitle("New Customer");
        stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     *  Method for opening the update customer form.
     *  Passes in the selectedCustomer object to initialize the update form.
     * @param event action event
     */
    @FXML
    public void OnActionOpenUpdateCustomer(ActionEvent event){
        selectedCustomer = CustomersTableView.getSelectionModel().getSelectedItem();
        try {
            if (CustomersTableView.getSelectionModel().isEmpty()) {
                Alert.invalidSelectionAlert();
                return;
            }
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/updateCustomerForm.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     * Gets selected Customer object from the customer Tableview.
     * The selected customer is used for the update and delete methods.
     * @return selectedCustomer
     */
    public static Customer getSelectedCustomer(){
        return selectedCustomer;
    }
    /**
     * Initializes the Customer Controller.
     * Sets Tableview column names and populates customer tableview.
     * Initializes the Customer TableView with All added Appointment Objects pulled from the MySQL database.
     * Lambda expressions used in this method for setting the cell values for the tableview columns. The reason for the
     * use of lambda expressions is PropertyValueFactory is not typesafe.
     * @param url
     * The location used to resolve relative paths for the root object, or
     * {@code null} if the location is not known.
     *
     * @param resourceBundle
     * The resources used to localize the root object, or {@code null} if
     * the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        CustomersTableView.setItems(Customer.allCustomers);
        User signedInUser = User.getSignedInUser();

        custIDCol.setCellValueFactory(cID -> new SimpleIntegerProperty(cID.getValue().getCustomerID()).asObject());
        custNameCol.setCellValueFactory(cName -> new SimpleStringProperty(cName.getValue().getCustomerName()));
        custAddressCol.setCellValueFactory(cAddre -> new SimpleStringProperty(cAddre.getValue().getCustomerAddress()));
        custPhoneCol.setCellValueFactory(cPhone -> new SimpleStringProperty(cPhone.getValue().getCustomerPhoneNum()));
        custPostalCodeCol.setCellValueFactory(cPostalCode -> new SimpleStringProperty(cPostalCode.getValue().getCustomerPostalCode()));
        custCountryCol.setCellValueFactory(cCountry -> new SimpleStringProperty(cCountry.getValue().getCustomerCountry()));
        custStateProvCol.setCellValueFactory(cStateProv -> new SimpleStringProperty(cStateProv.getValue().getCustomerDivision()));
        custDivIDCol.setCellValueFactory(cDivID -> new SimpleIntegerProperty(cDivID.getValue().getDivID()).asObject());
        custSignedInUserTxt.setText("Currently Signed in as: " + signedInUser.getUserName());
    }

}
