package jklimek.c195.myscheduler;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.JDBConnection;
import jklimek.c195.myscheduler.controllers.LoginFormController;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * myScheduler Main Application Method.
 * @author James Klimek | WGU CS195 Student
 */
public class mySchedulerMain extends Application {
    ResourceBundle rb = ResourceBundle.getBundle("/resource_bundles/ResourceBundle", Locale.getDefault());

    /**
     * Start Method.
     * Loads the login form.
     * @param stage the primary stage for this application, onto which
     * the application scene can be set.
     * Applications may create other stages, if needed, but they will not be
     * primary stages.
     */
    @Override
    public void start(Stage stage){
        try {
            FXMLLoader fxmlLoaderEN = new FXMLLoader(mySchedulerMain.class.getResource("/FXML/LoginForm.fxml"));
            Scene scene = new Scene(fxmlLoaderEN.load(), 439, 455);
            stage.setTitle(LoginFormController.getRb().getString("myScheduler") + " " + rb.getString("Login"));
            stage.setScene(scene);
            stage.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Main Method.
     * This is the first method called when the program is run.
     * @param args args
     */
    public static void main(String[] args){
        try {
            JDBConnection.openConnection();
            launch();
            JDBConnection.closeConnection();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}