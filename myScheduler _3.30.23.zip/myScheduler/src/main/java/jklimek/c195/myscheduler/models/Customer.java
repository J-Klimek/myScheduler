package jklimek.c195.myscheduler.models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jklimek.c195.myscheduler.Database.DBCustomers;
import java.time.LocalDateTime;

/**
 * Customer Class Model.
 * @author James Klimek | WGU CS195 Student
 */
public class Customer {
    private int customerID;
    private String customerName;
    private String customerAddress;
    private String customerPostalCode;
    private String customerPhoneNum;
    private String customerCountry;
    private String customerDivision;
    private int divID;
    private LocalDateTime createDate;
    private String createdBy;
    private LocalDateTime lastUpdatedDate;
    private String lastUpdatedBy;
    public static ObservableList<Customer> allCustomers = FXCollections.observableArrayList();

    /**
     * Default Constructor for Customer Objects.
     */
    public Customer(){}

    /**
     * Constructor for Customer Objects with just the ID.
     * @param customerID Customer ID
     */
    public Customer(int customerID) {
        this.customerID = customerID;
    }
    /**
     * Constructor for Customer Objects to use with ObservableList allCustomers and tableviews.
     * @param customerID Customer ID
     * @param customerName Customer Name
     * @param customerAddress Customer Address
     * @param customerPostalCode Customer Postal Code
     * @param customerPhoneNum Customer Phone Number
     * @param customerCountry Customer Country
     * @param customerDivision Customer Division
     * @param divID Division ID
     */
    public Customer(int customerID, String customerName, String customerAddress, String customerPostalCode, String customerPhoneNum, String customerCountry, String customerDivision, int divID) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPostalCode = customerPostalCode;
        this.customerPhoneNum = customerPhoneNum;
        this.customerCountry = customerCountry;
        this.customerDivision = customerDivision;
        this.divID = divID;
    }

    /**
     * Constructor for Inserting New Customers.
     * @param customerID Customer ID
     * @param customerName Customer Name
     * @param customerAddress Customer Address
     * @param customerPostalCode Customer Postal Code
     * @param customerPhoneNum Customer Phone Number
     * @param createDate Date/Time the Customer was created
     * @param createdBy User that created the Customer
     * @param lastUpdatedDate Date/Time the Customer was last updated
     * @param lastUpdatedBy User that last updated the Customer
     * @param divID Division ID
     */
    public Customer(int customerID, String customerName, String customerAddress, String customerPostalCode, String customerPhoneNum,
                    LocalDateTime createDate, String createdBy,
                    LocalDateTime lastUpdatedDate, String lastUpdatedBy, int divID) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPostalCode = customerPostalCode;
        this.customerPhoneNum = customerPhoneNum;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdatedDate = lastUpdatedDate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.divID = divID;
    }

    /**
     * Method to Get the Customer ID.
     * @return int Customer ID
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * Method to Get the Customer Name.
     * @return String Customer Name
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Method to Get the Customer Address.
     * @return String Customer Address
     */
    public String getCustomerAddress() {
        return customerAddress;
    }

    /**
     * Method to Get the Customer Postal Code
     * @return String Customer Postal Code
     */
    public String getCustomerPostalCode() {
        return customerPostalCode;
    }

    /**
     * Method to Get the Customer Phone Number.
     * @return String Customer Phone Number
     */
    public String getCustomerPhoneNum() {
        return customerPhoneNum;
    }

    /**
     * Method to Get the Customer Country.
     * @return String Customer Country
     */
    public String getCustomerCountry() {
        return customerCountry;
    }

    /**
     * Method to Get the Customer Division.
     * @return String Customer Division
     */
    public String getCustomerDivision() {
        return customerDivision;
    }

    /**
     * Method to Get the Division ID.
     * @return int Division ID
     */
    public int getDivID() {
        return divID;
    }

    /**
     * Static Method to Get All Customers.
     * @return ObservableList All Customer Objects
     */
    public static ObservableList<Customer> getAllCustomers() {
        return allCustomers;
    }

    /**
     * Static Method to Update a Customer Object.
     * @param indexOf Index of Customer object to be updated.
     * @param updatedCustomer Updated Customer Object to replace the existing one in the list.
     */
    public static void updateCustomer(int indexOf, Customer updatedCustomer) {
        Customer.allCustomers.set(indexOf, updatedCustomer);
    }

    /**
     * Static method that passes in a Customer object to be deleted.
     * Triggers Alert pop-up if selectedCustomer parameter is null.
     * @param selectedCustomer Customer object to be deleted.
     * @return False if selectedCustomer is null else True.
     */
    public static boolean deleteCustomer(Customer selectedCustomer){
        if (selectedCustomer == null) {
            Alert.invalidSelectionAlert();
            return false;
        } else {
            return true;
        }
    }

    /**
     * Override Method of the toString() method.
     * Override toString() to allow proper formatting in combo boxes.
     * @return String Customer ID: Customer Name
     */
    @Override //
    public String toString(){
        return customerID + ": " + customerName;
    }

    /**
     * Override Method of the equals() method.
     * Override equals() to allow comparing new Objects created from DB query
     * to existing ObservableList to avoid duplicates.
     * @param customer Object customer
     * @return false if Object is null or not equal, else true.
     */
    @Override //
    public boolean equals(Object customer) {
        if (customer == null || getClass() != customer.getClass()) {
            return false;
        }
        return this.customerID == ((Customer) customer).customerID;
    }

    /**
     * Override Method of the hashCode() method.
     * Override hashCode() to allow comparing new Objects created from DB query
     * to existing ObservableList to avoid duplicates.
     * @return int Customer ID
     */
    @Override //
    public int hashCode(){
        return customerID;
    }

    /**
     *
     * @param customerName
     * @return
     */
}