package jklimek.c195.myscheduler.controllers;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import jklimek.c195.myscheduler.Database.DBAppointments;
import jklimek.c195.myscheduler.models.Alert;
import jklimek.c195.myscheduler.models.Appointment;
import jklimek.c195.myscheduler.models.Contact;
import jklimek.c195.myscheduler.models.Customer;
import jklimek.c195.myscheduler.models.User;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import static java.time.LocalDateTime.now;

/**
 * Controller class for Update Appointment Form.
 * @author James Klimek | WGU CS195 Student
 */
public class UpdateAppointmentController implements Initializable {
    Stage stage;
    Parent scene;
    private static DateTimeFormatter formatterT = AppointmentsController.getFormatterT();

    @FXML
    private ComboBox<Contact> updateApptContactCombo;
    @FXML
    private TextField updateApptContactTxt;

    @FXML
    private ComboBox<Customer> updateApptCustIdCombo;

    @FXML
    private TextArea updateApptDescTxt;

    @FXML
    private DatePicker updateApptStartDate;

    @FXML
    private DatePicker updateApptEndDate;

    @FXML
    private ComboBox updateApptStartTime;

    @FXML
    private ComboBox updateApptEndTime;

    @FXML
    private TextField updateApptIdTxt;

    @FXML
    private TextField updateApptLocTxt;

    @FXML
    private TextField updateApptTitleTxt;

    @FXML
    private TextField updateApptTypeTxt;

    @FXML
    private ComboBox<User> updateApptUserIdCombo;

    /**
     * Method to cancel updating an appointment.
     * @param event not used
     */
    @FXML
    public void OnActionUpdateApptCancel(ActionEvent event){
        try {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/AppointmentsMainForm.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Appointments");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method to save the updated customer.
     * Takes in the user entered values from the form to update an existing customer.
     * Calls the DBAppointments update method to update the customer in the MySQL database.
     * Implements input validation to disallow blank entries in the fields and
     * checks for/disallows overlapping appointments.
     * @param event not used
     */
    @FXML
    public void OnActionUpdateApptSave(ActionEvent event) {

        Appointment selectedAppointment = AppointmentsController.getSelectedAppointment();
        int apptID = Integer.parseInt(updateApptIdTxt.getText());

        User signedInUser = User.getSignedInUser();
        String apptTitle;
        String apptDesc;
        String apptLoc;
        String apptType;
        LocalDate apptStartDate;
        LocalTime apptStartTime;
        LocalDateTime apptStartLDT;
        LocalDate apptEndDate;
        LocalTime apptEndTime;
        LocalDateTime apptEndLDT;
        LocalTime officeOpen = LocalTime.parse(AppointmentsController.getOfficeOpenLocal().format(AppointmentsController.getFormatterT()));
        LocalTime officeClose = LocalTime.parse(AppointmentsController.getOfficeCloseLocal().format(AppointmentsController.getFormatterT()));
        LocalDateTime createDate = Appointment.lookupAppt(Integer.parseInt(updateApptIdTxt.getText())).get(0).getApptCreateDate();
        String createdBy = Appointment.lookupAppt(Integer.parseInt(updateApptIdTxt.getText())).get(0).getApptCreatedBy();
        LocalDateTime apptLastUpdated = now();
        String apptLastUpdatedBy = signedInUser.getUserName();
        int customerID;
        int userID;
        int contactID;
        String contactName;

        try{
            apptTitle = updateApptTitleTxt.getText();
            if(apptTitle.isBlank()){
                jklimek.c195.myscheduler.models.Alert.invalidTitleAlert();
                return;
            }
            apptDesc = updateApptDescTxt.getText();
            if(apptDesc.isBlank()){
                jklimek.c195.myscheduler.models.Alert.invalidDescriptionAlert();
                return;
            }
            apptLoc = updateApptLocTxt.getText();
            if(apptLoc.isBlank()){
                jklimek.c195.myscheduler.models.Alert.invalidLocationAlert();
                return;
            }
            apptType = updateApptTypeTxt.getText();
            if(apptType.isBlank()){
                jklimek.c195.myscheduler.models.Alert.invalidTypeAlert();
                return;
            }
            if(updateApptCustIdCombo.getSelectionModel().isEmpty()){
                jklimek.c195.myscheduler.models.Alert.invalidCustomerIDAlert();
                return;
            }
            if(updateApptUserIdCombo.getSelectionModel().isEmpty()){
                jklimek.c195.myscheduler.models.Alert.invalidUserIDAlert();
                return;
            }
            if(updateApptContactCombo.getSelectionModel().isEmpty()){
                jklimek.c195.myscheduler.models.Alert.invalidContactIDAlert();
                return;
            }
            customerID = updateApptCustIdCombo.getValue().getCustomerID();
            userID = updateApptUserIdCombo.getValue().getUserID();
            contactID = updateApptContactCombo.getValue().getContactID();
            contactName = Contact.lookupContact(updateApptContactCombo.getValue().getContactID()).get(0).getContactName();

            apptStartDate = updateApptStartDate.getValue();
            apptStartTime = LocalTime.parse(updateApptStartTime.getValue().toString());

            apptEndDate = updateApptEndDate.getValue();
            apptEndTime = LocalTime.parse(updateApptEndTime.getValue().toString());

            apptStartLDT = LocalDateTime.of(apptStartDate, apptStartTime);
            apptEndLDT = LocalDateTime.of(apptEndDate, apptEndTime);
            if(updateApptStartTime.getSelectionModel().isEmpty()) {
                jklimek.c195.myscheduler.models.Alert.invalidNullDateTimeAlert();
                return;
            }
            if(updateApptEndTime.getSelectionModel().isEmpty()) {
                jklimek.c195.myscheduler.models.Alert.invalidNullDateTimeAlert();
                return;
            }

            // check for overlapping appointments
            for(Appointment appt : Appointment.allAppointments) {
                if(apptID == appt.getApptID()){
                    if(apptStartLDT.equals(appt.getApptStart()) && apptEndLDT.equals(appt.getApptEnd())) {
                        break;
                    }
                }
                if (customerID == appt.getCustomerID()) {
                    if ((apptStartLDT.isAfter(appt.getApptStart()) || apptStartLDT.isEqual(appt.getApptStart()))
                            && apptStartLDT.isBefore(appt.getApptEnd())) {
                        jklimek.c195.myscheduler.models.Alert.overlappingAppointmentAlert();
                        return;
                    } else if ((apptEndLDT.isBefore(appt.getApptEnd()) || apptEndLDT.isEqual(appt.getApptEnd()))
                            && apptEndLDT.isAfter(appt.getApptStart())) {
                        jklimek.c195.myscheduler.models.Alert.overlappingAppointmentAlert();
                        return;
                    } else if ((apptStartLDT.isBefore(appt.getApptStart()) || apptStartLDT.isEqual(appt.getApptStart()))
                            && ((apptEndLDT.isAfter(appt.getApptEnd()) || apptEndLDT.isEqual(appt.getApptEnd())))) {
                        jklimek.c195.myscheduler.models.Alert.overlappingAppointmentAlert();
                        return;
                    }
                }
            }

            if(apptStartTime.isBefore(officeOpen) || apptEndTime.isAfter(officeClose)) {
                jklimek.c195.myscheduler.models.Alert.outsideBusinessHoursAlert(apptStartTime, apptEndTime);
                return;
            }
            if(apptEndTime.isBefore(apptStartTime)){
                Alert.invalidTimeSelectionAlert();
                return;
            }


            DBAppointments.updateAppointment(apptID,apptTitle,apptDesc,apptLoc,apptType,apptStartLDT,apptEndLDT,
                                        createDate,createdBy,apptLastUpdated,apptLastUpdatedBy,
                                        customerID,userID,contactID);

            Appointment updatedAppointment = new Appointment(apptID,apptTitle,apptDesc,apptLoc,apptType,apptStartLDT,
                                                apptEndLDT,createDate,createdBy,apptLastUpdated,customerID,
                                                userID,contactID,contactName);

            Appointment.updateAppointment(Appointment.getAllAppointments().indexOf(selectedAppointment), updatedAppointment);


            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/FXML/AppointmentsMainForm.fxml"));
            stage.setScene(new Scene(scene));
            stage.setTitle("Appointments");
            stage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Method to initialize the Update Appointement Controller.
     * Takes the selected customer from the customer form and populates the values of the update form fields.
     * @param url
     * The location used to resolve relative paths for the root object, or
     * {@code null} if the location is not known.
     *
     * @param resourceBundle
     * The resources used to localize the root object, or {@code null} if
     * the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    Appointment selectedAppointment = AppointmentsController.getSelectedAppointment();

    String apptID = String.valueOf(selectedAppointment.getApptID());
    String apptTitle = selectedAppointment.getApptTitle();
    String apptDesc = selectedAppointment.getApptDesc();
    String apptLoc = selectedAppointment.getApptLoc();
    ObservableList<Contact> contacts = Contact.contactList;
    Contact currContact = new Contact(selectedAppointment.getContactID(), selectedAppointment.getContactName());
    String apptType = selectedAppointment.getApptType();
    LocalDate apptStartDate = selectedAppointment.getApptStart().toLocalDate();
    LocalDate apptEndDate = selectedAppointment.getApptEnd().toLocalDate();
    LocalTime apptStartTime = selectedAppointment.getApptStart().toLocalTime();
    LocalTime apptEndTime = selectedAppointment.getApptEnd().toLocalTime();
    LocalTime startAppt = LocalTime.of(1,0);
    LocalTime endAppt = LocalTime.of(23, 0);
    ObservableList<Customer> customers = Customer.allCustomers;
    Customer currCustomer = new Customer(selectedAppointment.getCustomerID());
    ObservableList<User> users = User.allUsers;
    User currUser = new User(selectedAppointment.getUserID());

    updateApptIdTxt.setText(apptID);
    updateApptTitleTxt.setText(apptTitle);
    updateApptDescTxt.setText(apptDesc);
    updateApptLocTxt.setText(apptLoc);
    updateApptContactCombo.setItems(contacts);
    updateApptContactCombo.setValue(currContact);
    updateApptTypeTxt.setText(apptType);
    while(startAppt.isBefore(endAppt)) {
        updateApptStartTime.getItems().add(startAppt.format(formatterT));
        updateApptEndTime.getItems().add(startAppt.plusMinutes(30).format(formatterT));
        startAppt = startAppt.plusHours(1);
    }
    updateApptStartDate.setValue(apptStartDate);
    updateApptStartTime.setValue(apptStartTime.format(formatterT));
    updateApptEndDate.setValue(apptEndDate);
    updateApptEndTime.setValue(apptEndTime.format(formatterT));
    updateApptCustIdCombo.setItems(customers);
    updateApptCustIdCombo.setValue(currCustomer);
    updateApptUserIdCombo.setItems(users);
    updateApptUserIdCombo.setValue(currUser);

    }
}
